export type KitType = 
  | 'smp'
  | 'shield'
  | 'netherite_chest'
  | 'gapple'
  | 'diamond_chest'
  | 'cart'
  | 'mace'
  | 'sword'
  | 'crystal'
  | 'uhc'
  | 'bow';

export type TierGrade = 
  | 'HT1' // High Tier 1
  | 'MT1' // Mid Tier 1
  | 'LT1' // Low Tier 1
  | 'HT2' // High Tier 2
  | 'MT2' // Mid Tier 2
  | 'LT2' // Low Tier 2
  | 'HT3' // High Tier 3
  | 'MT3' // Mid Tier 3
  | 'LT3' // Low Tier 3
  | 'HT4' // High Tier 4
  | 'MT4' // Mid Tier 4
  | 'LT4' // Low Tier 4
  | 'HT5' // High Tier 5
  | 'MT5' // Mid Tier 5
  | 'LT5' // Low Tier 5
  | 'HT6' // High Tier 6
  | 'MT6' // Mid Tier 6
  | 'LT6' // Low Tier 6
  | '???'; // Unranked / Not tested

export type Trend = 'up' | 'stable' | 'down';

export type UserRole = 'owner' | 'staff' | 'visitor';

export interface KitDefinition {
  id: KitType;
  name: string;
  shortName: string;
  icon: string;
  iconImage?: string;
  color: string;
  description: string;
}

export interface PlayerTier {
  id: string;
  username: string;
  country: string;
  countryName: string;
  overallTier: string; // e.g. "High Tier 2", "Mid Tier 1"
  points: number;
  trend: Trend;
  kits: Record<KitType, TierGrade>;
  testedBy?: string;
  lastTestedDate?: string;
  isOwnerPin?: boolean;
}

export interface StaffMember {
  id: string;
  email: string; // Gmail required for staff authorization
  username: string; // Minecraft IGN
  discord?: string; // Discord username / tag
  role: 'Owner' | 'Head Tester' | 'Tier Tester' | 'Trial Tester';
  testsConducted: number;
  joinedDate: string;
  status: 'active' | 'inactive' | 'pending';
}

export interface TierTestApplication {
  id: string;
  username: string; // Minecraft IGN
  discord: string;  // Discord handle
  email: string;    // Gmail
  primaryKit: KitType; // Primary testing kit
  claimedTier: TierGrade; // e.g. HT1, MT2, HT3...
  overallTier: string;    // e.g. High Tier 2
  weeklyHours: string;    // Hours available per week
  experience: string;     // Battle / testing experience
  language: 'ar' | 'en' | 'both';
  submittedDate: string;
  status: 'pending' | 'accepted' | 'rejected';
  notes?: string;
}

export interface AuthUser {
  id: string;
  username: string; // Minecraft IGN
  discord?: string; // Discord Tag (e.g. tag#1234 or @tag)
  email?: string;
  role: UserRole;
  registeredWith: 'minecraft' | 'discord';
  createdAt: string;
}

import { KitDefinition, PlayerTier, StaffMember } from '../types/playerTiers';

export const KITS: KitDefinition[] = [
  {
    id: 'smp',
    name: 'SMP (Pearl)',
    shortName: 'SMP',
    icon: 'ender_pearl',
    iconImage: '/assets/aistudio/image__7__6b40216b.png',
    color: '#10b981',
    description: 'Ender pearl maneuvering, clutching & totem cycling',
  },
  {
    id: 'shield',
    name: 'Shield PvP',
    shortName: 'Shield',
    icon: 'shield',
    iconImage: '/assets/aistudio/image_8a4359eb.png',
    color: '#854d0e',
    description: '100% damage block & axe counter attack mechanics',
  },
  {
    id: 'netherite_chest',
    name: 'Netherite Pot',
    shortName: 'N-Pot',
    icon: 'netherite_chest',
    iconImage: '/assets/aistudio/image__1__8ec55bbe.png',
    color: '#44403c',
    description: 'Speed II potion duels with Netherite armor',
  },
  {
    id: 'uhc',
    name: 'UHC',
    shortName: 'UHC',
    icon: 'uhc',
    iconImage: '/assets/aistudio/image__4__ba483a1b.png',
    color: '#facc15',
    description: 'Golden apple absorption pacing & no natural health regeneration',
  },
  {
    id: 'diamond_chest',
    name: 'Diamond SMP',
    shortName: 'Diamond',
    icon: 'diamond_chest',
    iconImage: '/assets/aistudio/image__6__a307b038.png',
    color: '#06b6d4',
    description: 'Standard 1.21 diamond armor combat',
  },
  {
    id: 'cart',
    name: 'Cart (TNT)',
    shortName: 'Cart',
    icon: 'tnt_cart',
    iconImage: '/assets/aistudio/image__5__efee6034.png',
    color: '#ef4444',
    description: 'High velocity rail TNT detonations & blast evasion',
  },
  {
    id: 'mace',
    name: 'Mace (1.21)',
    shortName: 'Mace',
    icon: 'mace',
    iconImage: '/assets/aistudio/image__3__2d6d70d5.png',
    color: '#f97316',
    description: '1.21 Heavy Core aerial smash mechanics & wind charge',
  },
  {
    id: 'sword',
    name: 'Diamond Sword',
    shortName: 'Sword',
    icon: 'sword',
    iconImage: '/assets/aistudio/image__8__8184cbe4.png',
    color: '#22d3ee',
    description: 'Sprint resets, critical combos & W-tap spacing',
  },
  {
    id: 'crystal',
    name: 'End Crystal',
    shortName: 'Crystal',
    icon: 'crystal',
    iconImage: '/assets/aistudio/image__9__94a32411.png',
    color: '#c084fc',
    description: 'Obsidian placement & explosive crystal anchor double hits',
  },
];

// No fake players! Only real players added by owner/staff in dashboard appear
export const INITIAL_PLAYERS: PlayerTier[] = [];

// Only the true Owner by Gmail (abdullafahmy13@gmail.com). Others added by owner.
export const INITIAL_STAFF: StaffMember[] = [
  {
    id: 'staff_owner',
    email: 'abdullafahmy13@gmail.com',
    username: 'Owner',
    discord: 'owner#0001',
    role: 'Owner',
    testsConducted: 0,
    joinedDate: '2026-10-27',
    status: 'active',
  },
];

import React, { useState, useMemo, useEffect } from 'react';
import { INITIAL_PLAYERS, KITS, INITIAL_STAFF } from './data/initialTierData';
import { PlayerTier, KitType, UserRole, StaffMember, TierTestApplication, AuthUser } from './types/playerTiers';
import { Navigation, NavTab } from './components/Navigation';
import { TopPlayersPodium } from './components/TopPlayersPodium';
import { LeaderboardTable } from './components/LeaderboardTable';
import { KitsListView } from './components/KitsListView';
import { StaffListView } from './components/StaffListView';
import { StaffDashboard } from './components/StaffDashboard';
import { StaffApplyModal } from './components/StaffApplyModal';
import { PlayerProfileModal } from './components/PlayerProfileModal';
import { DashboardPasswordModal } from './components/DashboardPasswordModal';
import { AuthModal } from './components/AuthModal';
import { 
  subscribeStaff, 
  subscribePlayers, 
  subscribeApplications, 
  subscribeSiteConfig,
  saveStaffMember,
  removeStaffMember,
  savePlayer,
  removePlayer,
  submitApplication,
  acceptApplicationInDb,
  rejectApplicationInDb,
  removeApplicationFromDb,
  updateSiteConfigInDb,
  getStoredUser,
  logoutUser
} from './services/firestoreService';
import { Search, Filter, Sparkles, Shield, Swords, Layers, Plus, Crown } from 'lucide-react';

export default function App() {
  // Navigation State - defaulted to 'tiers' (Main Leaderboard)
  const [activeTab, setActiveTab] = useState<NavTab>('tiers');

  // User Authentication State - Clean non-blocking modal
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(() => getStoredUser());
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'register' | 'login'>('register');

  // Role State: Default is STRICTLY 'visitor' for anyone in the world!
  // ONLY owner (abdullafahmy13@gmail.com) and staff added by owner have elevated roles.
  const [currentRole, setCurrentRole] = useState<UserRole>(() => {
    const user = getStoredUser();
    if (!user) return 'visitor';
    if (user.email === 'abdullafahmy13@gmail.com' || user.username.toLowerCase() === 'owner') {
      return 'owner';
    }
    return user.role || 'visitor';
  });

  // Dashboard Password Lock State
  const [isDashboardUnlocked, setIsDashboardUnlocked] = useState<boolean>(() => {
    const user = getStoredUser();
    return user?.email === 'abdullafahmy13@gmail.com' || user?.username.toLowerCase() === 'owner';
  });
  const [showPasswordModal, setShowPasswordModal] = useState(false);

  useEffect(() => {
    try {
      sessionStorage.setItem('mcpvp_dashboard_unlocked', String(isDashboardUnlocked));
    } catch (e) {}
  }, [isDashboardUnlocked]);

  // Apply Modal State
  const [showApplyModal, setShowApplyModal] = useState(false);

  // Staff TierTest Applications State - persisted in localStorage
  const [applications, setApplications] = useState<TierTestApplication[]>(() => {
    try {
      const saved = localStorage.getItem('mcpvp_staff_applications');
      if (saved) return JSON.parse(saved);
    } catch (e) {}
    return [
      {
        id: 'app_sample_1',
        username: 'CrystalGod_77',
        discord: 'crystalgod#1234',
        email: 'crystalgod77@gmail.com',
        primaryKit: 'crystal',
        claimedTier: 'HT2',
        overallTier: 'High Tier 2',
        weeklyHours: '15-25 hours/week',
        experience: 'Competitive crystal duelist with 3+ years experience. Active tester for EU tournaments.',
        language: 'both',
        submittedDate: new Date().toISOString().split('T')[0],
        status: 'pending',
      },
    ];
  });

  // Persist applications
  useEffect(() => {
    try {
      localStorage.setItem('mcpvp_staff_applications', JSON.stringify(applications));
    } catch (e) {}
  }, [applications]);

  // Staff Roster State - Persisted in localStorage so added staff survive page refresh
  const [staff, setStaff] = useState<StaffMember[]>(() => {
    try {
      const saved = localStorage.getItem('mcpvp_staff_members');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Failed to load staff from localStorage', e);
    }
    return INITIAL_STAFF;
  });

  // Persist staff changes to localStorage immediately
  useEffect(() => {
    try {
      localStorage.setItem('mcpvp_staff_members', JSON.stringify(staff));
    } catch (e) {
      console.error('Failed to save staff to localStorage', e);
    }
  }, [staff]);

  // Players Data State - No fake players! Only genuine players added by the owner
  const [players, setPlayers] = useState<PlayerTier[]>(() => {
    const fakeIds = ['p1_jokingdk', 'p2_xtki4ler', 'p3_spawnplayer', 'p4_jaidencrits', 'p5_provok', 'p6_0pminer17'];
    try {
      const saved = localStorage.getItem('mcpvp_players_data');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          const clean = parsed.filter((p) => !fakeIds.includes(p.id));
          return clean;
        }
      }
    } catch (e) {
      console.error('Failed to load players from localStorage', e);
    }
    return [];
  });

  // Persist players changes to localStorage immediately
  useEffect(() => {
    try {
      localStorage.setItem('mcpvp_players_data', JSON.stringify(players));
    } catch (e) {
      console.error('Failed to save players to localStorage', e);
    }
  }, [players]);

  // Site Title & Announcement - Persisted in localStorage
  const [siteTitle, setSiteTitle] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('mcpvp_site_title');
      if (saved && saved !== 'Minecraft PvP Tierlist') return saved;
    } catch (e) {}
    return 'DraftSMP-TierTest';
  });

  const [announcement, setAnnouncement] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('mcpvp_announcement');
      if (saved) return saved;
    } catch (e) {}
    return 'Season 4 Tier Testing is currently live! Authorized staff can login to test and add player tiers.';
  });

  useEffect(() => {
    try {
      localStorage.setItem('mcpvp_site_title', siteTitle);
      localStorage.setItem('mcpvp_announcement', announcement);
    } catch (e) {}
  }, [siteTitle, announcement]);

  // User Authentication Handlers
  const handleAuthSuccess = (user: AuthUser) => {
    setCurrentUser(user);
    setCurrentRole(user.role);
    if (user.role === 'owner') {
      setIsDashboardUnlocked(true);
    }
  };

  const handleLogout = () => {
    logoutUser();
    setCurrentUser(null);
    setCurrentRole('visitor');
    setActiveTab('tiers');
    setIsDashboardUnlocked(false);
  };

  // Real-time synchronization with Firestore across all users & devices
  useEffect(() => {
    const unsubStaff = subscribeStaff((liveStaff) => {
      if (liveStaff && liveStaff.length > 0) {
        setStaff(liveStaff);
      }
    });

    const unsubPlayers = subscribePlayers((livePlayers) => {
      setPlayers(livePlayers);
    });

    const unsubApps = subscribeApplications((liveApps) => {
      setApplications(liveApps);
    });

    const unsubConfig = subscribeSiteConfig((liveConfig) => {
      if (liveConfig.title) setSiteTitle(liveConfig.title);
      if (liveConfig.announcement) setAnnouncement(liveConfig.announcement);
    });

    return () => {
      unsubStaff();
      unsubPlayers();
      unsubApps();
      unsubConfig();
    };
  }, []);

  // Filter & Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedKitFilter, setSelectedKitFilter] = useState<KitType | 'all'>('all');
  const [selectedTierFilter, setSelectedTierFilter] = useState<string>('all');

  // Modal State
  const [inspectedPlayer, setInspectedPlayer] = useState<PlayerTier | null>(null);

  // Sort players by points descending
  const sortedPlayers = useMemo(() => {
    return [...players].sort((a, b) => b.points - a.points);
  }, [players]);

  // Top 3 players for podium
  const topThreePlayers = useMemo(() => {
    return sortedPlayers.slice(0, 3);
  }, [sortedPlayers]);

  // Filtered players based on kit, tier category, and search query
  const filteredPlayers = useMemo(() => {
    return sortedPlayers.filter((player) => {
      const matchesSearch =
        !searchQuery.trim() ||
        player.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
        player.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
        player.overallTier.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesTier =
        selectedTierFilter === 'all' ||
        player.overallTier.toLowerCase().includes(selectedTierFilter.toLowerCase());

      const matchesKit =
        selectedKitFilter === 'all' ||
        (player.kits[selectedKitFilter] && player.kits[selectedKitFilter] !== '???');

      return matchesSearch && matchesTier && matchesKit;
    });
  }, [sortedPlayers, searchQuery, selectedTierFilter, selectedKitFilter]);

  // Handle Role Change with safety guard
  const handleRoleChange = (role: UserRole) => {
    setCurrentRole(role);
    if (role === 'visitor' && activeTab === 'dashboard') {
      setActiveTab('tiers');
      setIsDashboardUnlocked(false);
    }
  };

  // Handle Tab Navigation with Password Guard - prompts EVERY time dashboard is clicked
  const handleTabChange = (tab: NavTab) => {
    if (tab === 'dashboard') {
      if (currentRole === 'visitor') {
        // Visitors cannot access staff dashboard
        return;
      }
      setShowPasswordModal(true);
      return;
    }
    setIsDashboardUnlocked(false);
    setActiveTab(tab);
  };

  const handlePasswordSuccess = () => {
    setIsDashboardUnlocked(true);
    setShowPasswordModal(false);
    setActiveTab('dashboard');
  };

  // Secret Owner Bypass via Staff Apply modal with pass: mcpvp.com
  const handleBypassToDashboard = () => {
    setCurrentRole('owner');
    if (!currentUser) {
      setCurrentUser({
        id: 'user_owner_bypass',
        username: 'Owner',
        email: 'abdullafahmy13@gmail.com',
        role: 'owner',
        registeredWith: 'minecraft',
        createdAt: new Date().toISOString(),
      });
    } else if (currentUser.role !== 'owner') {
      setCurrentUser({
        ...currentUser,
        role: 'owner',
      });
    }
    setIsDashboardUnlocked(true);
    setShowApplyModal(false);
    setActiveTab('dashboard');
  };

  const handleLockDashboard = () => {
    setIsDashboardUnlocked(false);
    setActiveTab('tiers');
  };

  // ================= CRITICAL OWNER ACTION: CROWN AS #1 =================
  const handleSetAsNumberOne = async (targetPlayer: PlayerTier) => {
    const highestPoints = Math.max(0, ...players.map((p) => p.points));
    const newPoints = highestPoints >= targetPlayer.points ? highestPoints + 15 : targetPlayer.points;

    const crownedPlayer: PlayerTier = {
      ...targetPlayer,
      points: newPoints,
      trend: 'up',
      isOwnerPin: true,
    };

    setPlayers((prev) =>
      prev.map((p) => (p.id === targetPlayer.id ? crownedPlayer : p))
    );

    try {
      await savePlayer(crownedPlayer);
    } catch (e) {
      console.error('Failed to crown player in Firestore:', e);
    }
  };

  // Add or update player from staff dashboard
  const handleAddOrUpdatePlayer = async (playerData: PlayerTier, makeNumberOne?: boolean) => {
    let finalPoints = playerData.points;
    if (makeNumberOne) {
      const currentHighest = Math.max(0, ...players.map((p) => p.points));
      finalPoints = currentHighest + 15;
    }

    const updatedPlayer: PlayerTier = {
      ...playerData,
      points: finalPoints,
      trend: makeNumberOne ? 'up' : playerData.trend,
    };

    setPlayers((prev) => {
      const existingIndex = prev.findIndex(
        (p) => p.id === updatedPlayer.id || p.username.toLowerCase() === updatedPlayer.username.toLowerCase()
      );

      if (existingIndex >= 0) {
        const copy = [...prev];
        copy[existingIndex] = updatedPlayer;
        return copy;
      } else {
        return [updatedPlayer, ...prev];
      }
    });

    try {
      await savePlayer(updatedPlayer);
    } catch (e) {
      console.error('Failed to save player in Firestore:', e);
    }
  };

  // Working Immediate Delete Player
  const handleDeletePlayer = async (playerId: string) => {
    setPlayers((prev) => prev.filter((p) => p.id !== playerId));
    try {
      await removePlayer(playerId);
    } catch (e) {
      console.error('Failed to delete player in Firestore:', e);
    }
  };

  // Staff management
  const handleAddStaff = async (newStaff: StaffMember) => {
    setStaff((prev) => [...prev, newStaff]);
    try {
      await saveStaffMember(newStaff);
    } catch (e) {
      console.error('Failed to save staff to Firestore:', e);
    }
  };

  const handleRemoveStaff = async (staffId: string) => {
    setStaff((prev) => prev.filter((s) => s.id !== staffId));
    try {
      await removeStaffMember(staffId);
    } catch (e) {
      console.error('Failed to remove staff from Firestore:', e);
    }
  };

  // Toggle staff active/inactive status in real time and persist to Firestore
  const handleToggleStaffStatus = async (staffId: string) => {
    const member = staff.find((s) => s.id === staffId);
    if (!member) return;
    const newStatus: 'active' | 'inactive' = member.status === 'active' ? 'inactive' : 'active';
    const updated: StaffMember = { ...member, status: newStatus };
    setStaff((prev) => prev.map((s) => (s.id === staffId ? updated : s)));
    try {
      await saveStaffMember(updated);
    } catch (e) {
      console.error('Failed to update staff status in Firestore:', e);
    }
  };

  // TierTest Application Handlers - Syncs to Firestore in real-time
  const handleAddApplication = async (newApp: TierTestApplication) => {
    setApplications((prev) => [newApp, ...prev]);
    try {
      await submitApplication(newApp);
    } catch (e) {
      console.error('Failed to submit application to Firestore:', e);
    }
  };

  // When owner accepts application:
  // 1. Marks application as accepted in Firestore
  // 2. Adds user to 'staff' collection in Firestore
  // Real-time onSnapshot immediately shows them on all connected users' screens!
  const handleAcceptApplication = async (app: TierTestApplication) => {
    try {
      const newStaff = await acceptApplicationInDb(app);
      setApplications((prev) =>
        prev.map((a) => (a.id === app.id ? { ...a, status: 'accepted' as const } : a))
      );
      setStaff((prev) => {
        if (prev.some((s) => s.id === newStaff.id || s.email.toLowerCase() === newStaff.email.toLowerCase())) {
          return prev;
        }
        return [...prev, newStaff];
      });
    } catch (e) {
      console.error('Failed to accept application in Firestore:', e);
    }
  };

  const handleRejectApplication = async (appId: string) => {
    setApplications((prev) =>
      prev.map((a) => (a.id === appId ? { ...a, status: 'rejected' as const } : a))
    );
    try {
      await rejectApplicationInDb(appId);
    } catch (e) {
      console.error('Failed to reject application in Firestore:', e);
    }
  };

  const handleDeleteApplication = async (appId: string) => {
    setApplications((prev) => prev.filter((a) => a.id !== appId));
    try {
      await removeApplicationFromDb(appId);
    } catch (e) {
      console.error('Failed to delete application in Firestore:', e);
    }
  };

  // Update Site Configuration in Firestore
  const handleUpdateSiteConfig = async (newTitle: string, newAnnouncement: string) => {
    setSiteTitle(newTitle);
    setAnnouncement(newAnnouncement);
    try {
      await updateSiteConfigInDb(newTitle, newAnnouncement);
    } catch (e) {
      console.error('Failed to update config in Firestore:', e);
    }
  };

  // Reset to default empty data
  const handleResetToDefaults = () => {
    setPlayers([]);
    setSiteTitle('DraftSMP-TierTest');
  };

  // When a kit is clicked from Kits list, jump to Tiers filtered by that kit
  const handleKitSelectFromList = (kitId: KitType) => {
    setSelectedKitFilter(kitId);
    setActiveTab('tiers');
  };

  return (
    <div className="min-h-screen relative flex flex-col bg-[#07080e] text-slate-100 select-none pb-16 overflow-x-hidden">
      {/* Background Golden Artwork: DraftSMP-TierTest - Clear and vividly visible */}
      <div
        className="fixed inset-0 z-0 bg-cover bg-center bg-no-repeat pointer-events-none transition-all duration-700"
        style={{
          backgroundImage: `url('/assets/aistudio/Gemini_Generated_Image_lk41rwlk41rwlk41_83b32ef8.jpg')`,
          filter: 'brightness(0.85) saturate(1.15) contrast(1.05)',
        }}
      />
      {/* Light soft translucent overlay to preserve readability while letting the entire background shine through */}
      <div className="fixed inset-0 z-0 bg-black/35 pointer-events-none" />
      <div className="fixed inset-0 z-0 bg-gradient-to-b from-black/40 via-transparent to-black/55 pointer-events-none" />
      {/* Radiant Top Glow */}
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[800px] h-[300px] bg-amber-500/15 blur-[120px] pointer-events-none z-0" />

      {/* Main Foreground Container */}
      <div className="relative z-10 flex flex-col min-h-screen">
        {/* Top Navigation in Orange Theme */}
        <Navigation
          activeTab={activeTab}
          onTabChange={handleTabChange}
          currentRole={currentRole}
          onRoleChange={handleRoleChange}
          isDashboardUnlocked={isDashboardUnlocked}
          onLockDashboard={handleLockDashboard}
          staff={staff}
          onOpenApply={() => setShowApplyModal(true)}
          currentUser={currentUser}
          onOpenAuth={() => {
            setAuthModalMode('login');
            setShowAuthModal(true);
          }}
          onLogout={handleLogout}
        />

        {/* Announcement Banner in Translucent Accent */}
        {announcement && (
          <div className="bg-black/30 backdrop-blur-md border-b border-amber-500/20 px-4 py-2 text-center text-xs text-amber-200/90 flex items-center justify-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span>{announcement}</span>
          </div>
        )}

        {/* Main View Area */}
        <main className="flex-1 w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 space-y-8">
          {/* ===================== TAB: TIERS (MAIN LEADERBOARD) ===================== */}
          {activeTab === 'tiers' && (
            <div className="space-y-8">
              {/* DraftSMP-TierTest Official Crest Banner */}
              <div className="relative overflow-hidden rounded-2xl border border-amber-500/35 bg-black/40 p-4 sm:p-5 shadow-[0_0_25px_rgba(245,158,11,0.18)] flex flex-col sm:flex-row items-center justify-between gap-4 backdrop-blur-md">
                <div className="flex items-center gap-4 text-center sm:text-left">
                  <div className="relative w-14 h-14 sm:w-16 sm:h-16 rounded-xl overflow-hidden border-2 border-amber-400/60 shadow-[0_0_20px_rgba(245,158,11,0.4)] shrink-0 group">
                    <img
                      src="/assets/aistudio/Gemini_Generated_Image_lk41rwlk41rwlk41_83b32ef8.jpg"
                      alt="DraftSMP-TierTest"
                      className="w-full h-full object-cover object-center group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 ring-1 ring-inset ring-amber-300/30 rounded-xl" />
                  </div>
                  <div>
                    <div className="flex items-center justify-center sm:justify-start gap-2">
                      <h1 className="font-pixel text-xl sm:text-2xl text-amber-300 font-bold tracking-wider drop-shadow-[0_2px_10px_rgba(245,158,11,0.5)]">
                        {siteTitle}
                      </h1>
                      <span className="px-2 py-0.5 rounded text-[10px] font-pixel bg-amber-500/20 text-amber-300 border border-amber-400/40 uppercase tracking-widest hidden sm:inline-block">
                        Official
                      </span>
                    </div>
                    <p className="text-xs text-amber-200/70 mt-1 max-w-xl font-medium">
                      The official competitive Minecraft PvP tier testing ranking system.
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-pixel text-amber-400 px-3 py-1.5 rounded-lg bg-amber-500/15 border border-amber-500/30 flex items-center gap-1.5 shadow-sm">
                    <Crown className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                    <span>Season 4 Live</span>
                  </span>
                </div>
              </div>

              {/* Top Players Podium in Orange Theme */}
              <TopPlayersPodium
                topPlayers={topThreePlayers}
                currentRole={currentRole}
                onSelectPlayer={setInspectedPlayer}
                onOpenDashboard={() => handleTabChange('dashboard')}
              />

            {/* Filter & Search Bar - Transparent Glass */}
            <div className="bg-black/35 backdrop-blur-md border border-amber-500/25 rounded-xl p-3 sm:p-4 flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3 shadow-xl">
              {/* Search */}
              <div className="relative flex-1 max-w-md">
                <Search className="w-4 h-4 text-amber-400/70 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search player IGN, country, or tier..."
                  className="w-full pl-9 pr-4 py-2 bg-black/40 border border-amber-500/25 rounded-lg text-xs text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-amber-400 transition-colors"
                />
              </div>

              {/* Kit & Tier Filters */}
              <div className="flex flex-wrap items-center gap-2">
                {/* Kit Filter */}
                <div className="flex items-center gap-1.5 bg-black/40 px-2.5 py-1.5 rounded-lg border border-amber-500/25 text-xs">
                  <Swords className="w-3.5 h-3.5 text-amber-400/80" />
                  <span className="text-amber-200/70 text-[11px] font-semibold">Kit:</span>
                  <select
                    value={selectedKitFilter}
                    onChange={(e) => setSelectedKitFilter(e.target.value as KitType | 'all')}
                    className="bg-transparent text-amber-100 text-xs font-pixel focus:outline-none cursor-pointer"
                  >
                    <option value="all" className="bg-[#0e101a] text-slate-200">All Kits</option>
                    {KITS.map((k) => (
                      <option key={k.id} value={k.id} className="bg-[#0e101a] text-slate-200">
                        {k.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Tier Filter */}
                <div className="flex items-center gap-1.5 bg-black/40 px-2.5 py-1.5 rounded-lg border border-amber-500/25 text-xs">
                  <Filter className="w-3.5 h-3.5 text-amber-400/80" />
                  <span className="text-amber-200/70 text-[11px] font-semibold">Tier:</span>
                  <select
                    value={selectedTierFilter}
                    onChange={(e) => setSelectedTierFilter(e.target.value)}
                    className="bg-transparent text-amber-100 text-xs font-pixel focus:outline-none cursor-pointer"
                  >
                    <option value="all" className="bg-[#0e101a] text-slate-200">All Tiers</option>
                    <option value="tier 1" className="bg-[#0e101a] text-slate-200">Tier 1</option>
                    <option value="tier 2" className="bg-[#0e101a] text-slate-200">Tier 2</option>
                    <option value="tier 3" className="bg-[#0e101a] text-slate-200">Tier 3</option>
                    <option value="tier 4" className="bg-[#0e101a] text-slate-200">Tier 4</option>
                    <option value="tier 5">Tier 5</option>
                    <option value="tier 6">Tier 6</option>
                  </select>
                </div>

                {/* Open Dashboard Button - ONLY VISIBLE TO STAFF AND OWNER */}
                {(currentRole === 'owner' || currentRole === 'staff') && (
                  <button
                    onClick={() => handleTabChange('dashboard')}
                    className="mc-button px-3 py-1.5 rounded text-xs font-pixel text-white bg-orange-600 hover:bg-orange-500 border-orange-400 cursor-pointer flex items-center gap-1.5 shadow-md"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>+ Add Player Tiers</span>
                  </button>
                )}
              </div>
            </div>

            {/* Leaderboard Table with working delete and hover tooltips */}
            <LeaderboardTable
              players={filteredPlayers}
              kits={KITS}
              currentRole={currentRole}
              onSelectPlayer={setInspectedPlayer}
              onSetAsNumberOne={handleSetAsNumberOne}
              onEditPlayer={(p) => {
                handleTabChange('dashboard');
              }}
              onDeletePlayer={handleDeletePlayer}
              onOpenDashboard={() => handleTabChange('dashboard')}
            />
          </div>
        )}

        {/* ===================== TAB: HOME ===================== */}
        {activeTab === 'home' && (
          <div className="space-y-8">
            <TopPlayersPodium
              topPlayers={topThreePlayers}
              currentRole={currentRole}
              onSelectPlayer={setInspectedPlayer}
              onOpenDashboard={() => handleTabChange('dashboard')}
            />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-[#0e101b] border border-orange-500/20 rounded-lg p-5">
                <div className="flex items-center gap-2 mb-2">
                  <Swords className="w-4 h-4 text-orange-400" />
                  <h3 className="font-pixel text-xs text-slate-200 uppercase">
                    Competitive Tier Testing
                  </h3>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Tier ratings (HT1 through LT5) are tested under strict competitive duels across official kit formats.
                </p>
              </div>

              <div className="bg-[#0e101b] border border-orange-500/20 rounded-lg p-5">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-4 h-4 text-orange-400" />
                  <h3 className="font-pixel text-xs text-slate-200 uppercase">
                    Staff Testing Protocol
                  </h3>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Certified tier testers evaluate movement, timing, combo accuracy, and crystal mechanics.
                </p>
              </div>

              <div className="bg-[#0e101b] border border-orange-500/20 rounded-lg p-5">
                <div className="flex items-center gap-2 mb-2">
                  <Layers className="w-4 h-4 text-orange-400" />
                  <h3 className="font-pixel text-xs text-slate-200 uppercase">
                    Kit Categories
                  </h3>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  Diamond SMP, Netherite Pot, Cart, Mace, Sword, Crystal, Bow, and UHC leaderboards.
                </p>
              </div>
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-pixel text-sm text-slate-200">Official Kits</h3>
                <button
                  onClick={() => setActiveTab('kits')}
                  className="text-xs text-orange-400 hover:underline font-pixel"
                >
                  View All Kits &gt;
                </button>
              </div>
              <KitsListView kits={KITS} onSelectKit={handleKitSelectFromList} />
            </div>
          </div>
        )}

        {/* ===================== TAB: KITS ===================== */}
        {activeTab === 'kits' && (
          <div className="space-y-4">
            <div className="bg-[#0e101b] border border-orange-500/20 rounded-lg p-4 flex items-center justify-between">
              <div>
                <h2 className="font-pixel text-base text-slate-100">Minecraft PvP Kits</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Click any kit to view individual player rankings and tier evaluations for that discipline.
                </p>
              </div>
            </div>
            <KitsListView kits={KITS} onSelectKit={handleKitSelectFromList} />
          </div>
        )}

        {/* ===================== TAB: STAFF LIST (REQUESTED BY USER) ===================== */}
        {activeTab === 'staff' && (
          <StaffListView
            staff={staff}
            currentRole={currentRole}
            onOpenDashboard={() => handleTabChange('dashboard')}
            onOpenApply={() => setShowApplyModal(true)}
            onToggleStaffStatus={handleToggleStaffStatus}
          />
        )}

        {/* ===================== TAB: STAFF & OWNER DASHBOARD ===================== */}
        {activeTab === 'dashboard' && isDashboardUnlocked && (
          <StaffDashboard
            players={sortedPlayers}
            kits={KITS}
            staff={staff}
            applications={applications}
            currentRole={currentRole}
            siteTitle={siteTitle}
            announcement={announcement}
            onAddOrUpdatePlayer={handleAddOrUpdatePlayer}
            onDeletePlayer={handleDeletePlayer}
            onSetAsNumberOne={handleSetAsNumberOne}
            onAddStaff={handleAddStaff}
            onRemoveStaff={handleRemoveStaff}
            onAcceptApplication={handleAcceptApplication}
            onRejectApplication={handleRejectApplication}
            onDeleteApplication={handleDeleteApplication}
            onUpdateSiteConfig={handleUpdateSiteConfig}
            onResetToDefaults={handleResetToDefaults}
            onLockDashboard={handleLockDashboard}
            onToggleStaffStatus={handleToggleStaffStatus}
          />
        )}
      </main>

      {/* User Auth Modal: Register & Login (Register First by Discord or Minecraft Username) */}
      <AuthModal
        isOpen={showAuthModal}
        onClose={() => setShowAuthModal(false)}
        onAuthSuccess={handleAuthSuccess}
        initialMode={authModalMode}
      />

      {/* Staff TierTest Apply Modal (تقديم ستاف تاير تستر) */}
      <StaffApplyModal
        isOpen={showApplyModal}
        onClose={() => setShowApplyModal(false)}
        kits={KITS}
        onSubmitApplication={handleAddApplication}
        onBypassToDashboard={handleBypassToDashboard}
      />

      {/* Password Modal for Dashboard (Password: mcpvp.com) */}
      <DashboardPasswordModal
        isOpen={showPasswordModal}
        onClose={() => setShowPasswordModal(false)}
        onSuccess={handlePasswordSuccess}
      />

      {/* Player Profile Modal */}
      {inspectedPlayer && (
        <PlayerProfileModal
          player={inspectedPlayer}
          kits={KITS}
          currentRole={currentRole}
          rank={sortedPlayers.findIndex((p) => p.id === inspectedPlayer.id) + 1}
          onClose={() => setInspectedPlayer(null)}
          onSetAsNumberOne={handleSetAsNumberOne}
        />
      )}
      </div>
    </div>
  );
}

import React, { useState } from 'react';
import { PlayerTier, KitDefinition, KitType, TierGrade, UserRole, StaffMember, TierTestApplication } from '../types/playerTiers';
import { PlayerAvatar } from './PlayerAvatar';
import { KitBadge } from './KitBadge';
import { 
  Shield, 
  Crown, 
  Mail, 
  UserPlus, 
  Check, 
  Trash2, 
  Edit3, 
  Search, 
  Sliders, 
  Users, 
  Settings, 
  Lock, 
  Plus, 
  MessageSquare, 
  Copy,
  FileText,
  CheckCircle,
  XCircle,
  Clock,
  Swords
} from 'lucide-react';

interface StaffDashboardProps {
  players: PlayerTier[];
  kits: KitDefinition[];
  staff: StaffMember[];
  applications: TierTestApplication[];
  currentRole: UserRole;
  siteTitle: string;
  announcement: string;
  onAddOrUpdatePlayer: (player: PlayerTier, makeNumberOne?: boolean) => void;
  onDeletePlayer: (playerId: string) => void;
  onSetAsNumberOne: (player: PlayerTier) => void;
  onAddStaff: (newStaff: StaffMember) => void;
  onRemoveStaff: (staffId: string) => void;
  onAcceptApplication: (app: TierTestApplication) => void;
  onRejectApplication: (appId: string) => void;
  onDeleteApplication: (appId: string) => void;
  onUpdateSiteConfig: (title: string, announcement: string) => void;
  onResetToDefaults: () => void;
  onLockDashboard: () => void;
  onToggleStaffStatus?: (staffId: string) => void;
}

const TIER_OPTIONS: TierGrade[] = [
  'HT1', 'MT1', 'LT1',
  'HT2', 'MT2', 'LT2',
  'HT3', 'MT3', 'LT3',
  'HT4', 'MT4', 'LT4',
  'HT5', 'MT5', 'LT5',
  'HT6', 'MT6', 'LT6',
  '???',
];

const OVERALL_TIERS = [
  'High Tier 1',
  'Mid Tier 1',
  'Low Tier 1',
  'High Tier 2',
  'Mid Tier 2',
  'Low Tier 2',
  'High Tier 3',
  'Mid Tier 3',
  'Low Tier 3',
  'High Tier 4',
  'Mid Tier 4',
  'Low Tier 4',
  'High Tier 5',
  'Mid Tier 5',
  'Low Tier 5',
  'High Tier 6',
  'Mid Tier 6',
  'Low Tier 6',
];

const COUNTRIES = [
  { code: 'DK', name: 'Denmark' },
  { code: 'DE', name: 'Germany' },
  { code: 'US', name: 'United States' },
  { code: 'IT', name: 'Italy' },
  { code: 'GB', name: 'United Kingdom' },
  { code: 'CA', name: 'Canada' },
  { code: 'FR', name: 'France' },
  { code: 'NL', name: 'Netherlands' },
  { code: 'SE', name: 'Sweden' },
  { code: 'ES', name: 'Spain' },
  { code: 'EG', name: 'Egypt' },
  { code: 'SA', name: 'Saudi Arabia' },
  { code: 'AE', name: 'United Arab Emirates' },
  { code: 'BR', name: 'Brazil' },
  { code: 'AU', name: 'Australia' },
  { code: 'JP', name: 'Japan' },
];

export const StaffDashboard: React.FC<StaffDashboardProps> = ({
  players,
  kits,
  staff,
  applications,
  currentRole,
  siteTitle,
  announcement,
  onAddOrUpdatePlayer,
  onDeletePlayer,
  onSetAsNumberOne,
  onAddStaff,
  onRemoveStaff,
  onAcceptApplication,
  onRejectApplication,
  onDeleteApplication,
  onUpdateSiteConfig,
  onResetToDefaults,
  onLockDashboard,
  onToggleStaffStatus,
}) => {
  // Active Tab inside Dashboard - default to 'applications' if any pending, or 'testing'
  const [subTab, setSubTab] = useState<'testing' | 'applications' | 'staff_roles' | 'crown_top' | 'settings'>('applications');
  const [copiedAppKey, setCopiedAppKey] = useState<string | null>(null);
  const [appSearch, setAppSearch] = useState('');
  const [appStatusFilter, setAppStatusFilter] = useState<'all' | 'pending' | 'accepted' | 'rejected'>('all');

  // Player Tier Testing Form State
  const [editingPlayerId, setEditingPlayerId] = useState<string | null>(null);
  const [username, setUsername] = useState('');
  const [country, setCountry] = useState('US');
  const [overallTier, setOverallTier] = useState('High Tier 2');
  const [points, setPoints] = useState<number>(250);
  const [trend, setTrend] = useState<PlayerTier['trend']>('stable');
  const [makeNumberOne, setMakeNumberOne] = useState(false);

  // Kits mapping state (default to '???' for untested kits)
  const [kitRatings, setKitRatings] = useState<Record<KitType, TierGrade>>({
    smp: 'HT1',
    shield: 'LT1',
    netherite_chest: 'LT1',
    uhc: 'HT2',
    gapple: 'HT2',
    diamond_chest: 'HT2',
    cart: '???', // 3 question marks as requested!
    mace: '???', // 3 question marks as requested!
    sword: 'HT3',
    crystal: 'HT3',
    bow: '???',
  });

  // Staff Gmail & Discord Management Form State
  const [staffGmail, setStaffGmail] = useState('');
  const [staffUsername, setStaffUsername] = useState('');
  const [staffDiscord, setStaffDiscord] = useState('');
  const [staffRole, setStaffRole] = useState<StaffMember['role']>('Tier Tester');
  const [staffStatus, setStaffStatus] = useState<'active' | 'inactive'>('active');

  // Crown Top Player select
  const [crownPlayerId, setCrownPlayerId] = useState<string>(players[0]?.id || '');

  // Site settings state
  const [titleInput, setTitleInput] = useState(siteTitle);
  const [announcementInput, setAnnouncementInput] = useState(announcement);

  // Feedback notifications
  const [alertMsg, setAlertMsg] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [searchRoster, setSearchRoster] = useState('');

  const triggerAlert = (text: string, type: 'success' | 'error' = 'success') => {
    setAlertMsg({ text, type });
    setTimeout(() => setAlertMsg(null), 3500);
  };

  // Reset form
  const handleResetPlayerForm = () => {
    setEditingPlayerId(null);
    setUsername('');
    setPoints(200);
    setMakeNumberOne(false);
  };

  // Edit existing player
  const handleLoadPlayerForEdit = (p: PlayerTier) => {
    setEditingPlayerId(p.id);
    setUsername(p.username);
    setCountry(p.country);
    setOverallTier(p.overallTier);
    setPoints(p.points);
    setTrend(p.trend);
    setKitRatings({ ...p.kits });
    setMakeNumberOne(false);
    setSubTab('testing');
    window.scrollTo({ top: 100, behavior: 'smooth' });
  };

  // Submit Player Tier Trial
  const handlePlayerSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim()) {
      triggerAlert('Please enter the player Minecraft In-Game Name (IGN)', 'error');
      return;
    }

    const countryObj = COUNTRIES.find((c) => c.code === country);
    const countryName = countryObj ? countryObj.name : country;

    const highestPoints = players.length > 0 ? Math.max(...players.map((p) => p.points)) : 280;
    let finalPoints = Number(points);
    if (makeNumberOne) {
      finalPoints = Math.max(finalPoints, highestPoints + 15);
    }

    const playerObj: PlayerTier = {
      id: editingPlayerId || `player_${Date.now()}`,
      username: username.trim(),
      country,
      countryName,
      overallTier,
      points: finalPoints,
      trend,
      kits: kitRatings,
      testedBy: currentRole === 'owner' ? 'Owner (abdullafahmy13@gmail.com)' : 'Staff Tester',
      lastTestedDate: new Date().toISOString().split('T')[0],
      isOwnerPin: makeNumberOne,
    };

    onAddOrUpdatePlayer(playerObj, makeNumberOne);
    triggerAlert(
      editingPlayerId
        ? `Updated tiers for ${playerObj.username} successfully!`
        : `Added ${playerObj.username} to leaderboard!` + (makeNumberOne ? ' (Crowned #1 Champion 👑)' : '')
    );

    handleResetPlayerForm();
  };

  // Instant Delete without browser window.confirm blocking
  const handleImmediateDelete = (playerId: string, playerName: string) => {
    onDeletePlayer(playerId);
    triggerAlert(`Player "${playerName}" removed from the leaderboard!`, 'success');
  };

  // Grant Staff Role via Gmail
  const handleAddStaffSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffGmail.trim() || !staffGmail.includes('@')) {
      triggerAlert('Please enter a valid Gmail address (e.g. name@gmail.com)', 'error');
      return;
    }
    if (!staffUsername.trim()) {
      triggerAlert('Please enter the staff member Minecraft in-game username (IGN)', 'error');
      return;
    }

    const newStaff: StaffMember = {
      id: `staff_${Date.now()}`,
      email: staffGmail.trim(),
      username: staffUsername.trim(),
      discord: staffDiscord.trim() || undefined,
      role: staffRole,
      testsConducted: 0,
      joinedDate: new Date().toISOString().split('T')[0],
      status: staffStatus,
    };

    onAddStaff(newStaff);
    setStaffGmail('');
    setStaffUsername('');
    setStaffDiscord('');
    triggerAlert(`Authorized ${newStaff.email} (${newStaff.username}) as ${newStaff.role}!`);
  };

  const handleCrownSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const target = players.find((p) => p.id === crownPlayerId);
    if (target) {
      onSetAsNumberOne(target);
      triggerAlert(`👑 ${target.username} has been crowned as the #1 Top Player!`);
    }
  };

  const filteredRoster = players.filter(
    (p) =>
      p.username.toLowerCase().includes(searchRoster.toLowerCase()) ||
      p.country.toLowerCase().includes(searchRoster.toLowerCase()) ||
      p.overallTier.toLowerCase().includes(searchRoster.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Executive Gaming Dashboard Header in Orange Theme */}
      <div className="bg-black/35 backdrop-blur-md border border-amber-500/30 rounded-xl p-5 shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-orange-500/15 border border-orange-500/40 flex items-center justify-center">
              <Shield className="w-5 h-5 text-orange-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="font-pixel text-lg text-slate-100">
                  Staff &amp; Owner Control Center
                </h2>
                <span className="bg-orange-500/20 text-orange-300 border border-orange-500/40 font-pixel text-[10px] px-2 py-0.5 rounded font-bold">
                  MCPVP UNLOCKED
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Manage Minecraft player in-game tiers, authorize staff roles via Gmail, and crown #1 champions.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Operator info */}
            <div className="flex items-center gap-2 bg-[#141727] px-3.5 py-1.5 rounded-lg border border-[#2b3052] text-xs">
              <Mail className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-slate-300 font-mono text-[11px]">abdullafahmy13@gmail.com</span>
              <span className="font-pixel text-[10px] bg-orange-500/20 text-orange-300 border border-orange-500/40 px-1.5 py-0.5 rounded font-bold">
                👑 OWNER
              </span>
            </div>

            {/* Lock dashboard button */}
            <button
              onClick={onLockDashboard}
              className="p-2 rounded-lg bg-[#141727] hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 border border-[#2b3052] cursor-pointer"
              title="Lock Dashboard (Requires mcpvp.com password to unlock)"
            >
              <Lock className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Dashboard Sub Navigation Tabs in Orange Accent */}
        <div className="flex items-center gap-2 mt-5 pt-4 border-t border-[#1c2038] overflow-x-auto">
          {/* Applications SubTab (يقولو و يوصلي في dash) */}
          <button
            onClick={() => setSubTab('applications')}
            className={`
              px-3.5 py-1.5 rounded-md font-pixel text-xs transition-all flex items-center gap-2 cursor-pointer shrink-0
              ${
                subTab === 'applications'
                  ? 'bg-orange-600 text-white shadow-[0_0_12px_rgba(234,88,12,0.4)] font-bold'
                  : 'bg-[#151829] text-slate-400 hover:text-slate-200'
              }
            `}
          >
            <FileText className="w-3.5 h-3.5 text-orange-400" />
            <span>TierTest Applications</span>
            {applications.filter((a) => a.status === 'pending').length > 0 ? (
              <span className="bg-amber-400 text-slate-950 font-bold px-1.5 py-0.2 rounded-full text-[10px] animate-pulse">
                {applications.filter((a) => a.status === 'pending').length} NEW
              </span>
            ) : (
              <span className="bg-[#242940] text-slate-300 px-1.5 py-0.2 rounded-full text-[10px]">
                {applications.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setSubTab('testing')}
            className={`
              px-3.5 py-1.5 rounded-md font-pixel text-xs transition-all flex items-center gap-2 cursor-pointer shrink-0
              ${
                subTab === 'testing'
                  ? 'bg-orange-600 text-white shadow-[0_0_12px_rgba(234,88,12,0.4)] font-bold'
                  : 'bg-[#151829] text-slate-400 hover:text-slate-200'
              }
            `}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Player In-Game Tiers (IGN)</span>
          </button>

          <button
            onClick={() => setSubTab('staff_roles')}
            className={`
              px-3.5 py-1.5 rounded-md font-pixel text-xs transition-all flex items-center gap-2 cursor-pointer shrink-0
              ${
                subTab === 'staff_roles'
                  ? 'bg-orange-600 text-white shadow-[0_0_12px_rgba(234,88,12,0.4)] font-bold'
                  : 'bg-[#151829] text-slate-400 hover:text-slate-200'
              }
            `}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Staff Roles by Gmail ({staff.length})</span>
          </button>

          <button
            onClick={() => setSubTab('crown_top')}
            className={`
              px-3.5 py-1.5 rounded-md font-pixel text-xs transition-all flex items-center gap-2 cursor-pointer
              ${
                subTab === 'crown_top'
                  ? 'bg-orange-600 text-white shadow-[0_0_12px_rgba(234,88,12,0.4)] font-bold'
                  : 'bg-[#151829] text-slate-400 hover:text-slate-200'
              }
            `}
          >
            <Crown className="w-3.5 h-3.5" />
            <span>Crown #1 Champion</span>
          </button>

          <button
            onClick={() => setSubTab('settings')}
            className={`
              px-3.5 py-1.5 rounded-md font-pixel text-xs transition-all flex items-center gap-2 cursor-pointer
              ${
                subTab === 'settings'
                  ? 'bg-orange-600 text-white shadow-[0_0_12px_rgba(234,88,12,0.4)] font-bold'
                  : 'bg-[#151829] text-slate-400 hover:text-slate-200'
              }
            `}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Web Settings</span>
          </button>
        </div>
      </div>

      {/* Alert Banner */}
      {alertMsg && (
        <div
          className={`p-3 rounded-lg border text-xs font-pixel flex items-center gap-2 animate-in fade-in ${
            alertMsg.type === 'success'
              ? 'bg-orange-500/15 border-orange-500/40 text-orange-300'
              : 'bg-rose-500/15 border-rose-500/40 text-rose-300'
          }`}
        >
          <Check className="w-4 h-4 text-orange-400" />
          <span>{alertMsg.text}</span>
        </div>
      )}

      {/* ======================= SUBTAB 1: PLAYER IN-GAME TIERS ======================= */}
      {subTab === 'testing' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Tier Submission Form */}
          <div className="lg:col-span-5 bg-[#0c0e18] border border-orange-500/20 rounded-xl p-5 shadow-lg">
            <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#1c2035]">
              <h3 className="font-pixel text-sm text-slate-100 flex items-center gap-2">
                <UserPlus className="w-4 h-4 text-orange-400" />
                <span>{editingPlayerId ? 'Edit Player Tier' : 'Add Player In-Game Name & Tiers'}</span>
              </h3>
              {editingPlayerId && (
                <button
                  onClick={handleResetPlayerForm}
                  className="text-[11px] text-slate-400 hover:text-white"
                >
                  Clear Edit
                </button>
              )}
            </div>

            <form onSubmit={handlePlayerSubmit} className="space-y-4 text-xs">
              {/* Minecraft In-Game Name (IGN) */}
              <div>
                <label className="block text-slate-300 font-semibold uppercase mb-1">
                  Minecraft In-Game Name (اسم اللاعب في اللعبة) *
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="e.g. JokingDK, XTki4ler, ColdiPvP"
                    className="flex-1 px-3 py-2 bg-[#121526] border border-[#282d4a] rounded-lg text-slate-100 font-pixel text-xs focus:outline-none focus:border-orange-500"
                  />
                  {username.trim() && (
                    <div className="w-10 h-10 rounded-lg bg-[#141729] border border-[#2b3152] flex items-center justify-center shrink-0">
                      <PlayerAvatar username={username.trim()} type="head" size={32} />
                    </div>
                  )}
                </div>
              </div>

              {/* Country & Overall Tier */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold uppercase mb-1">
                    Country
                  </label>
                  <select
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="w-full px-3 py-2 bg-[#121526] border border-[#282d4a] rounded-lg text-slate-100 text-xs font-pixel"
                  >
                    {COUNTRIES.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.code} - {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold uppercase mb-1">
                    Overall Tier
                  </label>
                  <select
                    value={overallTier}
                    onChange={(e) => setOverallTier(e.target.value)}
                    className="w-full px-3 py-2 bg-[#121526] border border-[#282d4a] rounded-lg text-slate-100 text-xs font-pixel"
                  >
                    {OVERALL_TIERS.map((tier) => (
                      <option key={tier} value={tier}>
                        {tier}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Points & Trend */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-semibold uppercase mb-1">
                    Leaderboard Points
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={points}
                    onChange={(e) => setPoints(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-[#121526] border border-[#282d4a] rounded-lg text-slate-100 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-slate-300 font-semibold uppercase mb-1">
                    Rank Trend
                  </label>
                  <select
                    value={trend}
                    onChange={(e) => setTrend(e.target.value as PlayerTier['trend'])}
                    className="w-full px-3 py-2 bg-[#121526] border border-[#282d4a] rounded-lg text-slate-100 text-xs"
                  >
                    <option value="stable">Stable (→)</option>
                    <option value="up">Rising (↗)</option>
                    <option value="down">Falling (↘)</option>
                  </select>
                </div>
              </div>

              {/* Crown as #1 Champion Toggle */}
              <div className="p-3 bg-orange-500/10 border border-orange-500/30 rounded-lg">
                <label className="flex items-center gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={makeNumberOne}
                    onChange={(e) => setMakeNumberOne(e.target.checked)}
                    className="w-4 h-4 rounded bg-[#121526] border-orange-500 text-orange-500 focus:ring-0"
                  />
                  <span className="font-pixel text-orange-300 text-xs flex items-center gap-1 font-bold">
                    <Crown className="w-3.5 h-3.5 fill-orange-400" />
                    Make Number 1 Player (Owner Power)
                  </span>
                </label>
                <p className="text-[10px] text-orange-400/80 mt-1 pl-6">
                  Sets points above all players and immediately puts them on the #1 podium!
                </p>
              </div>

              {/* Kit Tiers Grid */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-slate-300 font-semibold uppercase">
                    Kit Tier Grades ({kits.length} Kits)
                  </label>
                  <span className="text-[10px] text-slate-500">
                    Use ??? for unranked kits
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 max-h-56 overflow-y-auto p-1 bg-[#090b14] rounded-lg border border-[#1d2136]">
                  {kits.map((kit) => (
                    <div
                      key={kit.id}
                      className="p-2 rounded bg-[#111322] border border-[#21253a] flex items-center justify-between gap-1"
                    >
                      <span className="text-[11px] font-medium text-slate-300 truncate">
                        {kit.shortName || kit.name}
                      </span>
                      <select
                        value={kitRatings[kit.id] || '???'}
                        onChange={(e) =>
                          setKitRatings((prev) => ({
                            ...prev,
                            [kit.id]: e.target.value as TierGrade,
                          }))
                        }
                        className="px-1.5 py-0.5 bg-[#090a12] border border-[#282d46] rounded text-[10px] font-pixel text-orange-400 cursor-pointer"
                      >
                        {TIER_OPTIONS.map((g) => (
                          <option key={g} value={g}>
                            {g}
                          </option>
                        ))}
                      </select>
                    </div>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                className="mc-button w-full py-2.5 rounded-lg text-xs font-pixel text-white bg-orange-600 hover:bg-orange-500 border-orange-400 flex items-center justify-center gap-2 cursor-pointer font-bold shadow-md mt-2"
              >
                <Check className="w-4 h-4" />
                <span>{editingPlayerId ? 'Save Player Changes' : 'Publish Player to Leaderboard'}</span>
              </button>
            </form>
          </div>

          {/* Roster & Delete Column */}
          <div className="lg:col-span-7 bg-[#0c0e18] border border-orange-500/20 rounded-xl p-5 shadow-lg flex flex-col">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-[#1c2035]">
              <h3 className="font-pixel text-sm text-slate-100">
                Active Player Roster ({players.length} Players)
              </h3>

              <div className="relative w-full sm:w-60">
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchRoster}
                  onChange={(e) => setSearchRoster(e.target.value)}
                  placeholder="Search player or country..."
                  className="w-full pl-8 pr-3 py-1 bg-[#121526] border border-[#282d4a] rounded-lg text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none"
                />
              </div>
            </div>

            {players.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center py-16 text-center text-xs text-slate-400 font-pixel space-y-2">
                <p className="text-slate-300">Roster is completely empty.</p>
                <p className="text-slate-500 text-[11px]">Use the form on the left to add your first tested player!</p>
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto max-h-[580px] divide-y divide-[#171a2b]">
                {filteredRoster.map((player, index) => (
                  <div
                    key={player.id}
                    className="py-3 px-2 flex items-center justify-between gap-3 hover:bg-[#121424] rounded-lg transition-colors group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="font-pixel text-xs text-slate-500 w-5 text-right tabular-nums">
                        #{index + 1}
                      </span>
                      <PlayerAvatar username={player.username} type="head" size={34} />
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-pixel text-xs text-slate-100 truncate">
                            {player.username}
                          </span>
                          <span className="text-[10px] bg-[#171a2c] px-1.5 py-0.5 rounded border border-[#272b46] text-slate-400 font-pixel">
                            {player.country}
                          </span>
                          {index === 0 && (
                            <span className="bg-orange-500/20 text-orange-300 border border-orange-500/40 text-[9px] font-pixel px-1.5 py-0.2 rounded font-bold">
                              #1 CHAMPION
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          <span>{player.overallTier}</span>
                          <span className="mx-1 text-slate-600">·</span>
                          <span className="text-orange-400 font-mono">{player.points} pts</span>
                        </div>
                      </div>
                    </div>

                    {/* Actions with Working Delete */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      {index !== 0 && (
                        <button
                          type="button"
                          onClick={() => onSetAsNumberOne(player)}
                          className="p-1.5 rounded bg-orange-500/15 hover:bg-orange-500/30 text-orange-300 border border-orange-500/40 text-[11px] font-pixel flex items-center gap-1 cursor-pointer"
                          title="Crown as #1 Champion"
                        >
                          <Crown className="w-3.5 h-3.5 fill-orange-400 text-orange-400" />
                          <span className="hidden sm:inline">#1</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => handleLoadPlayerForEdit(player)}
                        className="p-1.5 rounded bg-[#171a2c] hover:bg-[#222740] text-slate-300 border border-[#2a2f4c] cursor-pointer"
                        title="Edit In-Game Tiers"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>

                      {/* Working Delete Button */}
                      <button
                        type="button"
                        onClick={() => handleImmediateDelete(player.id, player.username)}
                        className="p-1.5 rounded bg-rose-500/15 hover:bg-rose-500/30 text-rose-400 border border-rose-500/40 cursor-pointer shadow-sm hover:scale-105 transition-all"
                        title="Delete Player Instantly"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ======================= SUBTAB: TIERTEST APPLICATIONS (يقولو و يوصلي في dash) ======================= */}
      {subTab === 'applications' && (
        <div className="space-y-5 animate-in fade-in duration-200">
          {/* Header Bar with Filter & Search */}
          <div className="bg-[#0c0e18] border border-orange-500/25 rounded-xl p-4 sm:p-5 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 shadow-lg">
            <div>
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-orange-400" />
                <h3 className="font-pixel text-sm sm:text-base text-slate-100 font-bold">
                  TierTest Applications (تقديمات فاحصين التايرات)
                </h3>
                <span className="font-pixel text-[11px] px-2 py-0.5 rounded-full bg-orange-500/20 text-orange-300 border border-orange-500/40">
                  {applications.length} Total
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Applicants who submitted the "Staff TierTest Apply" form. Review their claimed tiers and accept them into the Staff team.
              </p>
            </div>

            {/* Filter Buttons */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setAppStatusFilter('all')}
                className={`px-2.5 py-1 rounded text-xs font-pixel cursor-pointer border ${
                  appStatusFilter === 'all'
                    ? 'bg-orange-500 text-slate-950 border-orange-300 font-bold'
                    : 'bg-[#14172a] text-slate-400 border-[#262c47]'
                }`}
              >
                All ({applications.length})
              </button>
              <button
                type="button"
                onClick={() => setAppStatusFilter('pending')}
                className={`px-2.5 py-1 rounded text-xs font-pixel cursor-pointer border ${
                  appStatusFilter === 'pending'
                    ? 'bg-amber-500 text-slate-950 border-amber-300 font-bold'
                    : 'bg-[#14172a] text-amber-300/80 border-[#262c47]'
                }`}
              >
                Pending ({applications.filter((a) => a.status === 'pending').length})
              </button>
              <button
                type="button"
                onClick={() => setAppStatusFilter('accepted')}
                className={`px-2.5 py-1 rounded text-xs font-pixel cursor-pointer border ${
                  appStatusFilter === 'accepted'
                    ? 'bg-emerald-500 text-slate-950 border-emerald-300 font-bold'
                    : 'bg-[#14172a] text-emerald-300/80 border-[#262c47]'
                }`}
              >
                Accepted ({applications.filter((a) => a.status === 'accepted').length})
              </button>
              <button
                type="button"
                onClick={() => setAppStatusFilter('rejected')}
                className={`px-2.5 py-1 rounded text-xs font-pixel cursor-pointer border ${
                  appStatusFilter === 'rejected'
                    ? 'bg-rose-500 text-slate-950 border-rose-300 font-bold'
                    : 'bg-[#14172a] text-rose-300/80 border-[#262c47]'
                }`}
              >
                Declined ({applications.filter((a) => a.status === 'rejected').length})
              </button>
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={appSearch}
              onChange={(e) => setAppSearch(e.target.value)}
              placeholder="Search application by IGN, Discord, Gmail, Tier, or Kit..."
              className="w-full pl-9 pr-4 py-2 bg-[#0c0e18] border border-[#232742] rounded-lg text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-orange-500"
            />
          </div>

          {/* Applications List */}
          {applications.length === 0 ? (
            <div className="py-16 text-center rounded-xl bg-[#0c0e18] border border-[#1e2238] p-8 space-y-3">
              <FileText className="w-10 h-10 text-slate-600 mx-auto" />
              <p className="font-pixel text-sm text-slate-300">No TierTest Applications Received Yet</p>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                When players click "Staff Apply" (تقديم تستر) on the website, their full application with their claimed tier, IGN, Discord, and Gmail will arrive here directly!
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {applications
                .filter((app) => {
                  const matchesStatus = appStatusFilter === 'all' || app.status === appStatusFilter;
                  const q = appSearch.toLowerCase().trim();
                  const matchesSearch =
                    !q ||
                    app.username.toLowerCase().includes(q) ||
                    app.discord.toLowerCase().includes(q) ||
                    app.email.toLowerCase().includes(q) ||
                    app.claimedTier.toLowerCase().includes(q) ||
                    app.primaryKit.toLowerCase().includes(q);
                  return matchesStatus && matchesSearch;
                })
                .map((app) => {
                  const isAccepted = app.status === 'accepted';
                  const isRejected = app.status === 'rejected';
                  const isPending = app.status === 'pending';

                  return (
                    <div
                      key={app.id}
                      className={`rounded-xl border p-5 flex flex-col justify-between space-y-4 shadow-xl transition-all ${
                        isAccepted
                          ? 'bg-[#0b1419] border-emerald-500/40'
                          : isRejected
                          ? 'bg-[#150d12] border-rose-500/40 opacity-75'
                          : 'bg-[#0c0e18] border-orange-500/35 hover:border-orange-500/60'
                      }`}
                    >
                      {/* Top Row: Skin + IGN + Tier + Status */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className="w-12 h-12 rounded-lg bg-[#14172a] border border-[#282e4b] flex items-center justify-center shrink-0 overflow-hidden shadow-inner">
                            <PlayerAvatar username={app.username} type="head" size={44} />
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-pixel text-sm text-slate-100 font-bold truncate">
                                {app.username}
                              </span>
                              <span className="font-pixel text-[11px] px-2 py-0.5 rounded bg-orange-500/20 text-orange-300 border border-orange-500/50 font-bold">
                                {app.claimedTier}
                              </span>
                            </div>
                            <span className="text-[11px] text-slate-400 block truncate">
                              {app.overallTier} · Primary: <span className="text-amber-300 uppercase font-mono">{app.primaryKit}</span>
                            </span>
                          </div>
                        </div>

                        {/* Status Badge */}
                        <div className="shrink-0">
                          {isPending && (
                            <span className="font-pixel text-[10px] px-2.5 py-1 rounded border bg-amber-500/20 text-amber-300 border-amber-500/40 flex items-center gap-1 font-bold animate-pulse">
                              <Clock className="w-3 h-3" />
                              <span>PENDING</span>
                            </span>
                          )}
                          {isAccepted && (
                            <span className="font-pixel text-[10px] px-2.5 py-1 rounded border bg-emerald-500/20 text-emerald-300 border-emerald-500/40 flex items-center gap-1 font-bold">
                              <CheckCircle className="w-3 h-3" />
                              <span>ACCEPTED</span>
                            </span>
                          )}
                          {isRejected && (
                            <span className="font-pixel text-[10px] px-2.5 py-1 rounded border bg-rose-500/20 text-rose-300 border-rose-500/40 flex items-center gap-1 font-bold">
                              <XCircle className="w-3 h-3" />
                              <span>DECLINED</span>
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Identifiers: Discord & Gmail */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                        {/* Discord */}
                        <div className="bg-[#121424] border border-[#20253d] rounded p-2 flex items-center justify-between gap-1.5 min-w-0">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <div className="w-3.5 h-3.5 rounded-full bg-[#5865F2] flex items-center justify-center shrink-0">
                              <MessageSquare className="w-2 h-2 text-white" />
                            </div>
                            <span className="font-mono text-indigo-300 text-[11px] truncate font-bold">
                              {app.discord}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(app.discord);
                              setCopiedAppKey(`disc_${app.id}`);
                              setTimeout(() => setCopiedAppKey(null), 2000);
                            }}
                            className="text-slate-400 hover:text-indigo-300 cursor-pointer p-0.5"
                            title="Copy Discord"
                          >
                            {copiedAppKey === `disc_${app.id}` ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>

                        {/* Gmail */}
                        <div className="bg-[#121424] border border-[#20253d] rounded p-2 flex items-center justify-between gap-1.5 min-w-0">
                          <div className="flex items-center gap-1.5 min-w-0">
                            <Mail className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                            <span className="font-mono text-slate-300 text-[11px] truncate">
                              {app.email}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(app.email);
                              setCopiedAppKey(`mail_${app.id}`);
                              setTimeout(() => setCopiedAppKey(null), 2000);
                            }}
                            className="text-slate-400 hover:text-orange-300 cursor-pointer p-0.5"
                            title="Copy Gmail"
                          >
                            {copiedAppKey === `mail_${app.id}` ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </div>

                      {/* Availability & Kit Specs */}
                      <div className="flex items-center gap-4 text-[11px] text-slate-400 border-t border-[#1a1e33] pt-2">
                        <span className="flex items-center gap-1 text-slate-300">
                          <Clock className="w-3 h-3 text-slate-500" />
                          <span>{app.weeklyHours}</span>
                        </span>
                        <span className="text-slate-600">·</span>
                        <span>Kit: <strong className="text-amber-400 uppercase font-mono">{app.primaryKit}</strong></span>
                        <span className="text-slate-600">·</span>
                        <span className="text-slate-500">Submitted {app.submittedDate}</span>
                      </div>

                      {/* Experience Text */}
                      <div className="bg-[#090b14] border border-[#1b1f33] rounded-lg p-2.5 text-xs text-slate-300 leading-relaxed font-sans">
                        <span className="text-[10px] uppercase font-pixel text-slate-500 block mb-1">
                          PvP Experience / نبذة عن مهارات الفحص:
                        </span>
                        "{app.experience}"
                      </div>

                      {/* Actions: Accept, Reject, Delete */}
                      <div className="pt-2 border-t border-[#1a1e33] flex items-center justify-between gap-2 flex-wrap">
                        <div className="flex items-center gap-2">
                          {!isAccepted && (
                            <button
                              type="button"
                              onClick={() => {
                                onAcceptApplication(app);
                                triggerAlert(`🎉 Accepted ${app.username} as Tier Tester and added to Staff roster!`);
                              }}
                              className="mc-button px-3 py-1.5 rounded text-[11px] font-pixel text-slate-950 bg-emerald-400 hover:bg-emerald-300 border-emerald-200 font-bold flex items-center gap-1.5 cursor-pointer shadow"
                            >
                              <CheckCircle className="w-3.5 h-3.5 text-slate-950" />
                              <span>Accept as Tier Tester (قبول)</span>
                            </button>
                          )}

                          {isPending && (
                            <button
                              type="button"
                              onClick={() => {
                                onRejectApplication(app.id);
                                triggerAlert(`Declined application for ${app.username}.`, 'error');
                              }}
                              className="px-2.5 py-1.5 rounded text-[11px] font-pixel text-slate-400 hover:text-rose-300 bg-[#161828] hover:bg-rose-500/15 border border-[#252a44] hover:border-rose-500/40 cursor-pointer"
                            >
                              Decline (رفض)
                            </button>
                          )}
                        </div>

                        {/* Delete Application */}
                        <button
                          type="button"
                          onClick={() => {
                            onDeleteApplication(app.id);
                            triggerAlert(`Application for ${app.username} removed.`);
                          }}
                          className="p-1.5 rounded text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 cursor-pointer"
                          title="Delete application"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
            </div>
          )}
        </div>
      )}

      {/* ======================= SUBTAB 2: STAFF ROLES BY GMAIL ======================= */}
      {subTab === 'staff_roles' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Grant Staff Role Form */}
          <div className="lg:col-span-5 bg-[#0c0e18] border border-orange-500/20 rounded-xl p-5 shadow-lg">
            <div className="pb-3 mb-4 border-b border-[#1c2035]">
              <h3 className="font-pixel text-sm text-slate-100 flex items-center gap-2">
                <Mail className="w-4 h-4 text-orange-400" />
                <span>Grant Staff Role by Gmail (إعطاء رتبة بالجيميل)</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                To give someone a staff rank, enter their personal Gmail address and Minecraft In-Game Name (IGN).
              </p>
            </div>

            <form onSubmit={handleAddStaffSubmit} className="space-y-4 text-xs">
              {/* Staff Gmail */}
              <div>
                <label className="block text-slate-300 font-semibold uppercase mb-1">
                  Staff Member Gmail Address (الجيميل) *
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={staffGmail}
                    onChange={(e) => setStaffGmail(e.target.value)}
                    placeholder="e.g. staffmember@gmail.com"
                    className="w-full pl-9 pr-3 py-2 bg-[#121526] border border-[#282d4a] rounded-lg text-slate-100 focus:outline-none focus:border-orange-500 font-mono"
                  />
                </div>
              </div>

              {/* Staff Minecraft IGN */}
              <div>
                <label className="block text-slate-300 font-semibold uppercase mb-1">
                  Staff Minecraft IGN (اسم اللاعب في اللعبة) *
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    required
                    value={staffUsername}
                    onChange={(e) => setStaffUsername(e.target.value)}
                    placeholder="e.g. KronoTester, ViperPvP"
                    className="flex-1 px-3 py-2 bg-[#121526] border border-[#282d4a] rounded-lg text-slate-100 font-pixel text-xs focus:outline-none focus:border-orange-500"
                  />
                  {staffUsername.trim() && (
                    <div className="w-9 h-9 rounded-lg bg-[#141729] border border-[#2b3152] flex items-center justify-center shrink-0">
                      <PlayerAvatar username={staffUsername.trim()} type="head" size={28} />
                    </div>
                  )}
                </div>
              </div>

              {/* Staff Discord Handle */}
              <div>
                <label className="block text-slate-300 font-semibold uppercase mb-1">
                  Discord Username / Tag (اسم الديسكورد)
                </label>
                <div className="relative">
                  <div className="w-4 h-4 rounded-full bg-[#5865F2] flex items-center justify-center absolute left-3 top-1/2 -translate-y-1/2">
                    <MessageSquare className="w-2.5 h-2.5 text-white" />
                  </div>
                  <input
                    type="text"
                    value={staffDiscord}
                    onChange={(e) => setStaffDiscord(e.target.value)}
                    placeholder="e.g. username or DiscordName#0000"
                    className="w-full pl-9 pr-3 py-2 bg-[#121526] border border-[#282d4a] rounded-lg text-slate-100 font-mono text-xs focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <span className="text-[10px] text-slate-500 mt-0.5 block">
                  Players can view this Discord handle to contact the tester directly.
                </span>
              </div>

              {/* Assigned Role */}
              <div>
                <label className="block text-slate-300 font-semibold uppercase mb-1">
                  Assigned Staff Rank / Role
                </label>
                <select
                  value={staffRole}
                  onChange={(e) => setStaffRole(e.target.value as StaffMember['role'])}
                  className="w-full px-3 py-2 bg-[#121526] border border-[#282d4a] rounded-lg text-slate-100 font-pixel text-xs"
                >
                  <option value="Head Tester">🛡️ Head Tester (Full test authority)</option>
                  <option value="Tier Tester">⚔️ Tier Tester (Can grade 1v1 duels)</option>
                  <option value="Trial Tester">🔍 Trial Tester (Probationary tester)</option>
                  <option value="Owner">👑 Co-Owner (Full website admin)</option>
                </select>
              </div>

              {/* Initial Staff Status */}
              <div>
                <label className="block text-slate-300 font-semibold uppercase mb-1">
                  Staff Status (حالة التفعيل)
                </label>
                <select
                  value={staffStatus}
                  onChange={(e) => setStaffStatus(e.target.value as 'active' | 'inactive')}
                  className="w-full px-3 py-2 bg-[#121526] border border-[#282d4a] rounded-lg text-slate-100 font-pixel text-xs"
                >
                  <option value="active">🟢 Active Tester (نشط - متاح للاختبارات)</option>
                  <option value="inactive">⚪ Inactive / Away (غير نشط - في إجازة)</option>
                </select>
              </div>

              <button
                type="submit"
                className="mc-button w-full py-2.5 rounded-lg text-xs font-pixel text-white bg-orange-600 hover:bg-orange-500 border-orange-400 flex items-center justify-center gap-2 cursor-pointer font-bold shadow-md"
              >
                <UserPlus className="w-4 h-4" />
                <span>Authorize &amp; Grant Staff Role</span>
              </button>
            </form>
          </div>

          {/* Authorized Staff Roster */}
          <div className="lg:col-span-7 bg-[#0c0e18] border border-orange-500/20 rounded-xl p-5 shadow-lg flex flex-col">
            <div className="pb-3 mb-4 border-b border-[#1c2035]">
              <h3 className="font-pixel text-sm text-slate-100 flex items-center justify-between">
                <span>Authorized Staff Roster ({staff.length})</span>
                <span className="text-[10px] text-orange-400">GMAIL &amp; DISCORD VERIFIED</span>
              </h3>
            </div>

            <div className="space-y-2.5 max-h-[500px] overflow-y-auto">
              {staff.map((s) => (
                <div
                  key={s.id}
                  className="p-3 rounded-lg bg-[#121526] border border-[#232844] flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <PlayerAvatar username={s.username} type="head" size={36} />
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-pixel text-xs text-slate-100 truncate">
                          {s.username}
                        </span>
                        <span className={`text-[10px] font-pixel px-2 py-0.5 rounded border ${
                          s.role === 'Owner'
                            ? 'bg-orange-500/20 text-orange-300 border-orange-500/40'
                            : s.role === 'Head Tester'
                            ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                            : 'bg-slate-700/40 text-slate-300 border-slate-600'
                        }`}>
                          {s.role}
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-3 mt-1 flex-wrap text-xs text-slate-400 font-mono">
                        <div className="flex items-center gap-1">
                          <Mail className="w-3 h-3 text-slate-500" />
                          <span className="truncate max-w-[150px]">{s.email}</span>
                        </div>

                        {s.discord && (
                          <div className="flex items-center gap-1 text-indigo-300 font-bold">
                            <div className="w-3 h-3 rounded-full bg-[#5865F2] flex items-center justify-center">
                              <MessageSquare className="w-2 h-2 text-white" />
                            </div>
                            <span className="truncate max-w-[120px]">@{s.discord.replace(/^@/, '')}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    {/* Real Active / Inactive Status Toggle */}
                    <button
                      type="button"
                      onClick={() => {
                        if (onToggleStaffStatus) {
                          onToggleStaffStatus(s.id);
                          triggerAlert(`Changed ${s.username}'s status to ${s.status === 'active' ? 'Inactive' : 'Active'}!`);
                        }
                      }}
                      className={`px-2.5 py-1 rounded text-[10px] font-pixel flex items-center gap-1.5 border cursor-pointer transition-all ${
                        s.status === 'active'
                          ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/25 shadow-[0_0_8px_rgba(16,185,129,0.2)]'
                          : 'bg-zinc-800 text-zinc-400 border-zinc-700 hover:bg-zinc-700 hover:text-zinc-200'
                      }`}
                      title={s.status === 'active' ? 'Click to make Inactive' : 'Click to make Active'}
                    >
                      <span
                        className={`w-2 h-2 rounded-full ${
                          s.status === 'active' ? 'bg-emerald-400 animate-pulse' : 'bg-zinc-500'
                        }`}
                      />
                      <span>{s.status === 'active' ? 'Active' : 'Inactive'}</span>
                    </button>

                    {s.role !== 'Owner' && (
                      <button
                        type="button"
                        onClick={() => onRemoveStaff(s.id)}
                        className="p-1.5 rounded bg-rose-500/10 hover:bg-rose-500/25 text-rose-400 border border-rose-500/30 cursor-pointer"
                        title="Revoke Staff Role"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ======================= SUBTAB 3: CROWN TOP PLAYER #1 ======================= */}
      {subTab === 'crown_top' && (
        <div className="max-w-2xl mx-auto bg-[#0c0e18] border-2 border-orange-500/40 rounded-xl p-6 shadow-2xl space-y-6">
          <div className="text-center space-y-1 pb-4 border-b border-[#212642]">
            <div className="w-12 h-12 rounded-full bg-orange-500/20 border-2 border-orange-400 flex items-center justify-center mx-auto mb-2 shadow-[0_0_16px_rgba(249,115,22,0.4)]">
              <Crown className="w-6 h-6 text-orange-400 fill-orange-400" />
            </div>
            <h3 className="font-pixel text-lg text-orange-300 font-bold">
              Owner Top Player #1 Control
            </h3>
            <p className="text-xs text-slate-400">
              Select any player to immediately crown them as Rank #1 on the podium and leaderboard.
            </p>
          </div>

          {players.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400 font-pixel">
              No players exist yet. Add a player first in the "Player In-Game Tiers" tab!
            </div>
          ) : (
            <form onSubmit={handleCrownSubmit} className="space-y-4">
              <div>
                <label className="block text-slate-300 font-semibold uppercase text-xs mb-1.5">
                  Select Player to Crown as #1
                </label>
                <select
                  value={crownPlayerId}
                  onChange={(e) => setCrownPlayerId(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#121526] border border-[#2b3052] rounded-lg text-slate-100 font-pixel text-xs focus:outline-none focus:border-orange-500"
                >
                  {players.map((p, idx) => (
                    <option key={p.id} value={p.id}>
                      #{idx + 1} {p.username} ({p.country} · {p.overallTier} · {p.points} pts)
                    </option>
                  ))}
                </select>
              </div>

              <button
                type="submit"
                className="mc-button w-full py-3 px-4 rounded-lg text-xs font-pixel text-slate-950 bg-orange-500 hover:bg-orange-400 border-orange-300 flex items-center justify-center gap-2 cursor-pointer font-bold shadow-lg"
              >
                <Crown className="w-4 h-4 fill-slate-950 text-slate-950" />
                <span>Make Selected Player #1 Right Now</span>
              </button>
            </form>
          )}
        </div>
      )}

      {/* ======================= SUBTAB 4: WEB SETTINGS ======================= */}
      {subTab === 'settings' && (
        <div className="max-w-2xl mx-auto bg-[#0c0e18] border border-orange-500/20 rounded-xl p-6 shadow-lg space-y-6">
          <div className="pb-3 border-b border-[#1c2035]">
            <h3 className="font-pixel text-sm text-slate-100 flex items-center gap-2">
              <Settings className="w-4 h-4 text-orange-400" />
              <span>Website Configuration &amp; Branding</span>
            </h3>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              onUpdateSiteConfig(titleInput, announcementInput);
              triggerAlert('Website settings saved!');
            }}
            className="space-y-4 text-xs"
          >
            <div>
              <label className="block text-slate-300 font-semibold uppercase mb-1">
                Leaderboard Branding Title
              </label>
              <input
                type="text"
                value={titleInput}
                onChange={(e) => setTitleInput(e.target.value)}
                className="w-full px-3 py-2 bg-[#121526] border border-[#282d4a] rounded-lg text-slate-100"
              />
            </div>

            <div>
              <label className="block text-slate-300 font-semibold uppercase mb-1">
                Top Announcement Alert
              </label>
              <textarea
                rows={3}
                value={announcementInput}
                onChange={(e) => setAnnouncementInput(e.target.value)}
                className="w-full px-3 py-2 bg-[#121526] border border-[#282d4a] rounded-lg text-slate-100"
              />
            </div>

            <div className="flex items-center justify-between pt-3 border-t border-[#1c2035]">
              <button
                type="button"
                onClick={() => {
                  onResetToDefaults();
                  triggerAlert('Reset all data!');
                }}
                className="px-3 py-1.5 rounded text-xs text-rose-400 hover:text-white border border-rose-500/30"
              >
                Clear All Roster
              </button>

              <button
                type="submit"
                className="mc-button px-5 py-2 rounded-lg text-xs font-pixel text-slate-950 bg-orange-500 hover:bg-orange-400 border-orange-300 flex items-center gap-1.5 cursor-pointer font-bold shadow-md"
              >
                <Check className="w-3.5 h-3.5" />
                <span>Save Site Settings</span>
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};

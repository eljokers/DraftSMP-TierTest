import React from 'react';
import { PlayerTier, KitDefinition, UserRole } from '../types/playerTiers';
import { PlayerAvatar } from './PlayerAvatar';
import { KitBadge } from './KitBadge';
import { Crown, ArrowRight, ArrowUpRight, ArrowDownRight, Edit3, Trash2, Plus, MessageSquare } from 'lucide-react';

interface LeaderboardTableProps {
  players: PlayerTier[];
  kits: KitDefinition[];
  currentRole: UserRole;
  onSelectPlayer: (player: PlayerTier) => void;
  onSetAsNumberOne?: (player: PlayerTier) => void;
  onEditPlayer?: (player: PlayerTier) => void;
  onDeletePlayer?: (playerId: string) => void;
  onOpenDashboard?: () => void;
}

export const LeaderboardTable: React.FC<LeaderboardTableProps> = ({
  players,
  kits,
  currentRole,
  onSelectPlayer,
  onSetAsNumberOne,
  onEditPlayer,
  onDeletePlayer,
  onOpenDashboard,
}) => {
  const getRankBadgeStyle = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-br from-amber-400 via-amber-500 to-orange-500 text-slate-950 font-bold border-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.5)]';
      case 2:
        return 'bg-gradient-to-br from-slate-200 to-slate-400 text-slate-950 font-bold border-slate-200 shadow-[0_0_10px_rgba(203,213,225,0.4)]';
      case 3:
        return 'bg-gradient-to-br from-amber-600 via-amber-700 to-amber-800 text-amber-100 font-bold border-amber-600 shadow-[0_0_10px_rgba(217,119,6,0.3)]';
      default:
        return 'bg-[#121422] text-slate-400 border-[#22273c] font-semibold';
    }
  };

  const getAvatarBorderStyle = (rank: number) => {
    switch (rank) {
      case 1:
        return 'ring-2 ring-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.5)]';
      case 2:
        return 'ring-2 ring-slate-300 shadow-[0_0_8px_rgba(203,213,225,0.4)]';
      case 3:
        return 'ring-2 ring-amber-600 shadow-[0_0_8px_rgba(217,119,6,0.4)]';
      default:
        return 'ring-1 ring-[#22273c]';
    }
  };

  const renderTrendIcon = (trend: PlayerTier['trend']) => {
    switch (trend) {
      case 'up':
        return (
          <span title="Rising rank" className="inline-flex items-center text-emerald-400 font-bold ml-1">
            <ArrowUpRight className="w-3.5 h-3.5" />
          </span>
        );
      case 'down':
        return (
          <span title="Falling rank" className="inline-flex items-center text-rose-400 font-bold ml-1">
            <ArrowDownRight className="w-3.5 h-3.5" />
          </span>
        );
      default:
        return (
          <span title="Steady rank" className="inline-flex items-center text-slate-500 ml-1">
            <ArrowRight className="w-3.5 h-3.5 text-slate-500" />
          </span>
        );
    }
  };

  return (
    <div className="w-full bg-black/40 backdrop-blur-md border border-amber-500/25 rounded-xl overflow-hidden shadow-2xl">
      {/* Table Header matching Attachment 4 */}
      <div className="grid grid-cols-12 px-4 sm:px-6 py-3.5 bg-black/40 border-b border-amber-500/20 text-[11px] font-pixel text-amber-200/80 uppercase tracking-wider select-none">
        <div className="col-span-1 text-center font-bold">#</div>
        <div className="col-span-5 sm:col-span-4">PLAYER</div>
        <div className="col-span-2 text-center">COUNTRY</div>
        <div className="col-span-4 sm:col-span-5 text-right sm:text-left sm:pl-3">
          CONTRIBUTING KITS
        </div>
      </div>

      {/* Table Rows */}
      <div className="divide-y divide-amber-500/10">
        {players.length === 0 ? (
          <div className="py-16 text-center text-xs font-pixel space-y-4 px-4">
            <p className="text-base text-amber-300 font-bold tracking-wide">
              No players currently on leaderboard
            </p>
            <div>
              <a
                href="https://discord.gg/vyywzf6yX"
                target="_blank"
                rel="noopener noreferrer"
                className="mc-button px-4 py-2 rounded-lg text-xs font-pixel text-white bg-[#5865F2] hover:bg-[#4752c4] border-indigo-400 cursor-pointer inline-flex items-center gap-2 font-bold shadow-md"
              >
                <MessageSquare className="w-4 h-4 text-white" />
                <span>Join Discord to Test (https://discord.gg/vyywzf6yX)</span>
              </a>
            </div>
            {(currentRole === 'owner' || currentRole === 'staff') && onOpenDashboard && (
              <div className="pt-2">
                <button
                  type="button"
                  onClick={onOpenDashboard}
                  className="mc-button px-4 py-2 rounded-lg text-xs font-pixel text-slate-950 bg-amber-400 hover:bg-amber-300 font-bold cursor-pointer inline-flex items-center gap-1.5 shadow"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Open Dashboard to Add Player</span>
                </button>
              </div>
            )}
          </div>
        ) : (
          players.map((player, index) => {
            const rank = index + 1;

            return (
              <div
                key={player.id}
                onClick={() => onSelectPlayer(player)}
                className={`
                  grid grid-cols-12 items-center px-4 sm:px-6 py-3.5 transition-all cursor-pointer group relative
                  ${rank === 1 ? 'bg-amber-500/[0.12] hover:bg-amber-500/[0.20]' : ''}
                  ${rank === 2 ? 'bg-slate-300/[0.08] hover:bg-slate-300/[0.16]' : ''}
                  ${rank === 3 ? 'bg-amber-700/[0.08] hover:bg-amber-700/[0.16]' : ''}
                  ${rank > 3 ? 'hover:bg-amber-500/10' : ''}
                `}
              >
                {/* Column 1: Rank Number Badge */}
                <div className="col-span-1 flex justify-center">
                  <div
                    className={`
                      w-7 h-7 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center font-pixel text-xs sm:text-sm border
                      ${getRankBadgeStyle(rank)}
                    `}
                  >
                    {rank}
                  </div>
                </div>

                {/* Column 2: Player Avatar + Username + Points */}
                <div className="col-span-5 sm:col-span-4 flex items-center gap-3 min-w-0 pr-2">
                  <div className={`rounded-full overflow-hidden shrink-0 ${getAvatarBorderStyle(rank)}`}>
                    <PlayerAvatar username={player.username} type="head" size={38} />
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1">
                      <span className="font-pixel text-xs sm:text-sm text-slate-100 group-hover:text-amber-400 transition-colors truncate font-bold">
                        {player.username}
                      </span>
                      {renderTrendIcon(player.trend)}
                    </div>
                    <div className="text-[11px] text-slate-400 truncate mt-0.5">
                      <span className="font-medium text-slate-300">{player.overallTier}</span>
                      <span className="mx-1 text-slate-600">·</span>
                      <span className="tabular-nums text-slate-400 font-mono">({player.points} Points)</span>
                    </div>
                  </div>
                </div>

                {/* Column 3: Country */}
                <div className="col-span-2 text-center">
                  <span className="font-pixel text-xs sm:text-sm text-slate-200 font-bold">
                    {player.country}
                  </span>
                </div>

                {/* Column 4: Contributing Kits Matching Attachment 4 */}
                <div className="col-span-4 sm:col-span-5 flex items-center justify-end sm:justify-between flex-wrap gap-1 sm:pl-3">
                  <div className="flex items-center gap-1 sm:gap-1.5 overflow-x-auto py-1 max-w-full scrollbar-none">
                    {kits.map((kit) => {
                      const grade = player.kits[kit.id] || (kit.id === 'uhc' ? player.kits.gapple : undefined) || '???';
                      return (
                        <KitBadge
                          key={kit.id}
                          kitId={kit.id}
                          grade={grade}
                        />
                      );
                    })}
                  </div>

                  {/* Owner Controls (Hover Only) */}
                  {currentRole === 'owner' && (
                    <div className="hidden lg:flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity ml-2 shrink-0">
                      {rank !== 1 && onSetAsNumberOne && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onSetAsNumberOne(player);
                          }}
                          className="px-2 py-1 rounded bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 text-[10px] font-pixel flex items-center gap-1 cursor-pointer"
                          title="Crown as #1"
                        >
                          <Crown className="w-3 h-3 text-amber-400" />
                          <span>#1</span>
                        </button>
                      )}

                      {onEditPlayer && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onEditPlayer(player);
                          }}
                          className="p-1 rounded bg-[#1b1f33] hover:bg-[#252a44] text-slate-400 hover:text-white border border-[#2b314e] cursor-pointer"
                          title="Edit"
                        >
                          <Edit3 className="w-3 h-3" />
                        </button>
                      )}

                      {onDeletePlayer && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onDeletePlayer(player.id);
                          }}
                          className="p-1 rounded bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 cursor-pointer"
                          title="Delete"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

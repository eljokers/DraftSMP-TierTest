import React, { useState } from 'react';
import { PlayerTier, UserRole } from '../types/playerTiers';
import { PlayerAvatar } from './PlayerAvatar';
import { Crown, MessageSquare } from 'lucide-react';

interface TopPlayersPodiumProps {
  topPlayers: PlayerTier[];
  currentRole: UserRole;
  onSelectPlayer: (player: PlayerTier) => void;
  onOpenDashboard?: () => void;
}

interface TiltOffset {
  rotX: number;
  rotY: number;
  transX: number;
  transY: number;
}

export const TopPlayersPodium: React.FC<TopPlayersPodiumProps> = ({
  topPlayers,
  currentRole,
  onSelectPlayer,
}) => {
  const p1 = topPlayers[0];
  const p2 = topPlayers[1];
  const p3 = topPlayers[2];

  // Mouse tracking state for 3D character tilt
  const [tilts, setTilts] = useState<Record<number, TiltOffset>>({
    1: { rotX: 0, rotY: 0, transX: 0, transY: 0 },
    2: { rotX: 0, rotY: 0, transX: 0, transY: 0 },
    3: { rotX: 0, rotY: 0, transX: 0, transY: 0 },
  });

  // Dance state triggered by hovering on the dance line
  const [dancingRanks, setDancingRanks] = useState<Record<number, boolean>>({
    1: false,
    2: false,
    3: false,
  });

  const handleCardMouseMove = (rank: number, e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;

    const rotY = Math.max(-20, Math.min(20, (x / (rect.width / 2)) * 18));
    const rotX = Math.max(-14, Math.min(14, -(y / (rect.height / 2)) * 12));
    const transX = Math.max(-8, Math.min(8, (x / (rect.width / 2)) * 8));
    const transY = Math.max(-5, Math.min(5, (y / (rect.height / 2)) * 5));

    setTilts((prev) => ({
      ...prev,
      [rank]: { rotX, rotY, transX, transY },
    }));
  };

  const handleCardMouseLeave = (rank: number) => {
    setTilts((prev) => ({
      ...prev,
      [rank]: { rotX: 0, rotY: 0, transX: 0, transY: 0 },
    }));
  };

  const setDancing = (rank: number, isDancing: boolean) => {
    setDancingRanks((prev) => ({
      ...prev,
      [rank]: isDancing,
    }));
  };

  return (
    <section className="relative overflow-hidden rounded-2xl bg-black/35 backdrop-blur-md border border-amber-500/30 py-8 sm:py-10 px-4 text-center shadow-2xl">
      {/* Background Starry Nebula & Glow */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-48 bg-amber-500/10 blur-[80px] pointer-events-none" />

      {/* Decorative Golden Laurel Wreath on Right - Matching Attachment 3 */}
      <div className="absolute right-2 sm:right-6 md:right-10 top-1/2 -translate-y-1/2 pointer-events-none opacity-40 select-none">
        <svg viewBox="0 0 100 200" className="w-16 sm:w-24 h-36 sm:h-52 stroke-amber-500 fill-amber-500/15">
          <path d="M50 10 C20 40 20 80 40 120 C50 140 60 170 50 190" fill="none" strokeWidth="2.5" />
          <ellipse cx="32" cy="35" rx="7" ry="4" transform="rotate(-30 32 35)" />
          <ellipse cx="25" cy="65" rx="8" ry="4" transform="rotate(-20 25 65)" />
          <ellipse cx="27" cy="95" rx="8" ry="4" transform="rotate(-10 27 95)" />
          <ellipse cx="38" cy="125" rx="8" ry="4" transform="rotate(10 38 125)" />
          <ellipse cx="48" cy="155" rx="7" ry="4" transform="rotate(25 48 155)" />
        </svg>
      </div>

      {/* Header Title: Warm Gold font-pixel */}
      <div className="relative mb-6">
        <h2 className="font-pixel text-xl sm:text-2xl text-amber-400 font-bold tracking-wide drop-shadow-[0_0_12px_rgba(245,158,11,0.5)]">
          Top Players
        </h2>
        <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400 mt-1">
          <span>Official Season Rankings</span>
          <span className="text-amber-500/60">·</span>
          <span className="text-amber-400/90 font-pixel">Hover to dance 🕺</span>
        </div>
      </div>

      {/* Podium Layout [2] [1] [3] Matching User Reference Attachment 3 */}
      <div className="relative flex items-end justify-center gap-2.5 sm:gap-5 max-w-xl mx-auto pt-2">
        {/* ================= Rank 2 (Left - Silver) ================= */}
        <div
          onMouseMove={(e) => handleCardMouseMove(2, e)}
          onMouseLeave={() => handleCardMouseLeave(2)}
          className="group flex-1 max-w-[170px] flex flex-col items-center transition-transform duration-200"
        >
          <div
            onClick={() => p2 && onSelectPlayer(p2)}
            className="w-full bg-black/40 backdrop-blur-sm border border-slate-300/40 hover:border-slate-200 rounded-t-xl p-3 flex flex-col items-center cursor-pointer relative shadow-lg"
          >
            {/* Username */}
            <span className="font-pixel text-xs sm:text-sm text-slate-100 font-bold truncate w-full group-hover:text-white">
              {p2 ? p2.username : '???'}
            </span>

            {/* Character Standing on Pedestal */}
            <div className="my-2 h-28 sm:h-32 flex items-center justify-center relative perspective-[500px]">
              {dancingRanks[2] && (
                <div className="absolute inset-0 pointer-events-none z-20 flex items-center justify-center">
                  <span className="text-slate-200 font-bold text-sm animate-mc-note-1">♪</span>
                  <span className="text-amber-300 font-bold text-base animate-mc-note-2 ml-4">♫</span>
                </div>
              )}

              <div
                className={`transition-transform duration-100 ease-out ${
                  dancingRanks[2] ? 'animate-mc-dance' : ''
                }`}
                style={
                  dancingRanks[2]
                    ? {}
                    : {
                        transform: `perspective(500px) rotateY(${tilts[2].rotY}deg) rotateX(${tilts[2].rotX}deg) translateX(${tilts[2].transX}px) translateY(${tilts[2].transY}px)`,
                      }
                }
              >
                <PlayerAvatar username={p2 ? p2.username : '???'} type="body" size={54} />
              </div>
            </div>

            {/* Points / Tier text */}
            <span className="text-[10px] text-slate-400 tabular-nums">
              {p2 ? `${p2.points} pts` : 'Pending'}
            </span>

            {/* Hover Dance Line */}
            <div
              onMouseEnter={() => setDancing(2, true)}
              onMouseLeave={() => setDancing(2, false)}
              className="w-full mt-2 pt-1 cursor-pointer group/line"
              title="Hover to dance"
            >
              <div
                className={`h-1 w-full rounded-full transition-all duration-200 ${
                  dancingRanks[2]
                    ? 'bg-slate-200 shadow-[0_0_10px_rgba(255,255,255,0.8)]'
                    : 'bg-[#22273e] group-hover/line:bg-slate-300'
                }`}
              />
            </div>
          </div>

          {/* Silver Base #2 */}
          <div
            onMouseEnter={() => setDancing(2, true)}
            onMouseLeave={() => setDancing(2, false)}
            onClick={() => p2 && onSelectPlayer(p2)}
            className="w-full h-16 sm:h-20 bg-gradient-to-t from-black/60 via-slate-800/40 to-slate-700/50 backdrop-blur-sm border-t-2 border-slate-300 rounded-b-xl flex items-center justify-center shadow-md cursor-pointer hover:border-slate-100 transition-colors"
          >
            <span className="font-pixel text-3xl sm:text-4xl font-bold text-slate-300 drop-shadow">
              2
            </span>
          </div>
        </div>

        {/* ================= Rank 1 (Center - Gold Champion, Taller) ================= */}
        <div
          onMouseMove={(e) => handleCardMouseMove(1, e)}
          onMouseLeave={() => handleCardMouseLeave(1)}
          className="group flex-1 max-w-[195px] flex flex-col items-center z-10 transition-transform duration-200"
        >
          <div
            onClick={() => p1 && onSelectPlayer(p1)}
            className="w-full bg-black/50 backdrop-blur-sm border-2 border-amber-400/80 hover:border-amber-300 rounded-t-xl p-3.5 flex flex-col items-center shadow-[0_0_30px_rgba(245,158,11,0.25)] cursor-pointer relative"
          >
            {/* Username in Gold */}
            <div className="flex items-center gap-1.5 justify-center w-full">
              <Crown className="w-3.5 h-3.5 text-amber-400 fill-amber-400 shrink-0" />
              <span className="font-pixel text-xs sm:text-base text-amber-300 font-bold truncate group-hover:text-amber-200">
                {p1 ? p1.username : '???'}
              </span>
            </div>

            {/* Character Standing on Pedestal */}
            <div className="my-2 h-32 sm:h-36 flex items-center justify-center relative perspective-[500px]">
              {dancingRanks[1] && (
                <div className="absolute inset-0 pointer-events-none z-20 flex items-center justify-center">
                  <span className="text-amber-300 font-bold text-base animate-mc-note-1">♪</span>
                  <span className="text-yellow-400 font-bold text-lg animate-mc-note-2 ml-5">♫</span>
                </div>
              )}

              <div
                className={`transition-transform duration-100 ease-out scale-110 ${
                  dancingRanks[1] ? 'animate-mc-dance' : ''
                }`}
                style={
                  dancingRanks[1]
                    ? {}
                    : {
                        transform: `perspective(500px) rotateY(${tilts[1].rotY}deg) rotateX(${tilts[1].rotX}deg) translateX(${tilts[1].transX}px) translateY(${tilts[1].transY}px)`,
                      }
                }
              >
                <PlayerAvatar username={p1 ? p1.username : '???'} type="body" size={60} />
              </div>
            </div>

            {/* Points / Tier text */}
            <span className="text-[10px] text-amber-300 font-pixel font-bold tabular-nums">
              {p1 ? `${p1.points} pts` : 'No #1 set yet'}
            </span>

            {/* Hover Dance Line */}
            <div
              onMouseEnter={() => setDancing(1, true)}
              onMouseLeave={() => setDancing(1, false)}
              className="w-full mt-2 pt-1 cursor-pointer group/line"
              title="Hover to dance"
            >
              <div
                className={`h-1.5 w-full rounded-full transition-all duration-200 ${
                  dancingRanks[1]
                    ? 'bg-amber-400 shadow-[0_0_12px_rgba(251,191,36,0.9)]'
                    : 'bg-amber-500/40 group-hover/line:bg-amber-400'
                }`}
              />
            </div>
          </div>

          {/* Gold Base #1 */}
          <div
            onMouseEnter={() => setDancing(1, true)}
            onMouseLeave={() => setDancing(1, false)}
            onClick={() => p1 && onSelectPlayer(p1)}
            className="w-full h-20 sm:h-24 bg-gradient-to-t from-black/60 via-amber-950/40 to-amber-600/50 backdrop-blur-sm border-t-2 border-amber-400 rounded-b-xl flex items-center justify-center shadow-xl cursor-pointer hover:border-amber-300 transition-colors"
          >
            <span className="font-pixel text-4xl sm:text-5xl font-bold text-amber-400 drop-shadow-[0_2px_10px_rgba(245,158,11,0.6)]">
              1
            </span>
          </div>
        </div>

        {/* ================= Rank 3 (Right - Bronze) ================= */}
        <div
          onMouseMove={(e) => handleCardMouseMove(3, e)}
          onMouseLeave={() => handleCardMouseLeave(3)}
          className="group flex-1 max-w-[170px] flex flex-col items-center transition-transform duration-200"
        >
          <div
            onClick={() => p3 && onSelectPlayer(p3)}
            className="w-full bg-black/40 backdrop-blur-sm border border-amber-700/50 hover:border-amber-500 rounded-t-xl p-3 flex flex-col items-center cursor-pointer relative shadow-lg"
          >
            {/* Username */}
            <span className="font-pixel text-xs sm:text-sm text-amber-400 font-bold truncate w-full group-hover:text-amber-300">
              {p3 ? p3.username : '???'}
            </span>

            {/* Character Standing on Pedestal */}
            <div className="my-2 h-28 sm:h-32 flex items-center justify-center relative perspective-[500px]">
              {dancingRanks[3] && (
                <div className="absolute inset-0 pointer-events-none z-20 flex items-center justify-center">
                  <span className="text-amber-500 font-bold text-sm animate-mc-note-1">♪</span>
                  <span className="text-orange-400 font-bold text-base animate-mc-note-2 ml-4">♫</span>
                </div>
              )}

              <div
                className={`transition-transform duration-100 ease-out ${
                  dancingRanks[3] ? 'animate-mc-dance' : ''
                }`}
                style={
                  dancingRanks[3]
                    ? {}
                    : {
                        transform: `perspective(500px) rotateY(${tilts[3].rotY}deg) rotateX(${tilts[3].rotX}deg) translateX(${tilts[3].transX}px) translateY(${tilts[3].transY}px)`,
                      }
                }
              >
                <PlayerAvatar username={p3 ? p3.username : '???'} type="body" size={54} />
              </div>
            </div>

            {/* Points / Tier text */}
            <span className="text-[10px] text-slate-400 tabular-nums">
              {p3 ? `${p3.points} pts` : 'Pending'}
            </span>

            {/* Hover Dance Line */}
            <div
              onMouseEnter={() => setDancing(3, true)}
              onMouseLeave={() => setDancing(3, false)}
              className="w-full mt-2 pt-1 cursor-pointer group/line"
              title="Hover to dance"
            >
              <div
                className={`h-1 w-full rounded-full transition-all duration-200 ${
                  dancingRanks[3]
                    ? 'bg-amber-600 shadow-[0_0_10px_rgba(217,119,6,0.8)]'
                    : 'bg-[#22273e] group-hover/line:bg-amber-600'
                }`}
              />
            </div>
          </div>

          {/* Bronze Base #3 */}
          <div
            onMouseEnter={() => setDancing(3, true)}
            onMouseLeave={() => setDancing(3, false)}
            onClick={() => p3 && onSelectPlayer(p3)}
            className="w-full h-16 sm:h-20 bg-gradient-to-t from-black/60 via-amber-950/30 to-amber-800/40 backdrop-blur-sm border-t-2 border-amber-700 rounded-b-xl flex items-center justify-center shadow-md cursor-pointer hover:border-amber-600 transition-colors"
          >
            <span className="font-pixel text-3xl sm:text-4xl font-bold text-amber-500 drop-shadow">
              3
            </span>
          </div>
        </div>
      </div>

      {/* Invitation Discord Link if visitor wants to test */}
      <div className="mt-6 pt-4 border-t border-[#161a2c] flex items-center justify-center gap-3 flex-wrap">
        <span className="text-xs text-slate-400 font-pixel">
          Want to test your tiers?
        </span>
        <a
          href="https://discord.gg/vyywzf6yX"
          target="_blank"
          rel="noopener noreferrer"
          className="text-xs font-pixel text-amber-300 hover:text-white bg-[#5865F2]/20 hover:bg-[#5865F2]/40 border border-[#5865F2]/50 px-3 py-1 rounded-lg inline-flex items-center gap-1.5 transition-colors"
        >
          <MessageSquare className="w-3.5 h-3.5 text-[#5865F2]" />
          <span>discord.gg/vyywzf6yX</span>
        </a>
      </div>
    </section>
  );
};

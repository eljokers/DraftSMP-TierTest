import React from 'react';
import { PlayerTier, KitDefinition, UserRole } from '../types/playerTiers';
import { PlayerAvatar } from './PlayerAvatar';
import { KitBadge } from './KitBadge';
import { X, Crown, Calendar, ShieldCheck } from 'lucide-react';

interface PlayerProfileModalProps {
  player: PlayerTier | null;
  kits: KitDefinition[];
  currentRole: UserRole;
  rank: number;
  onClose: () => void;
  onSetAsNumberOne: (player: PlayerTier) => void;
}

export const PlayerProfileModal: React.FC<PlayerProfileModalProps> = ({
  player,
  kits,
  currentRole,
  rank,
  onClose,
  onSetAsNumberOne,
}) => {
  if (!player) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-[#0f111a] border-2 border-[#262a3f] rounded-xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="relative px-6 py-4 bg-[#141724] border-b border-[#212538] flex items-center justify-between">
          <div className="flex items-center gap-2">
            {rank === 1 && <Crown className="w-4 h-4 text-amber-400 fill-amber-400" />}
            <span className="font-pixel text-xs text-slate-400">
              Rank #{rank} · {player.countryName} ({player.country})
            </span>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded hover:bg-white/5 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Player Showcase & 3D Skin */}
        <div className="p-6 space-y-6">
          <div className="flex flex-col sm:flex-row items-center gap-6 pb-6 border-b border-[#1c2033]">
            {/* 3D Skin Body */}
            <div className="w-28 h-40 flex items-center justify-center bg-[#090b12] rounded-lg border border-[#202438] p-2 shrink-0">
              <PlayerAvatar username={player.username} type="body" size={72} />
            </div>

            {/* Player Info */}
            <div className="flex-1 text-center sm:text-left space-y-2">
              <div className="flex items-center justify-center sm:justify-start gap-2">
                <h3 className="font-pixel text-xl sm:text-2xl text-slate-100 font-bold">
                  {player.username}
                </h3>
                {rank === 1 && (
                  <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-pixel px-2 py-0.5 rounded">
                    #1 CHAMPION
                  </span>
                )}
              </div>

              <div className="font-pixel text-sm text-emerald-400">
                {player.overallTier}
              </div>

              <div className="text-xs text-slate-400 flex items-center justify-center sm:justify-start gap-3">
                <span className="font-mono text-amber-400 font-semibold text-sm">
                  {player.points} Points
                </span>
                <span>·</span>
                <span className="capitalize">Trend: {player.trend}</span>
              </div>

              <div className="text-[11px] text-slate-500 pt-1 flex items-center justify-center sm:justify-start gap-3">
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
                  Tested by: {player.testedBy || 'Staff'}
                </span>
                {player.lastTestedDate && (
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-slate-500" />
                    {player.lastTestedDate}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Contributing Kit Breakdown */}
          <div>
            <h4 className="font-pixel text-xs text-slate-300 uppercase tracking-wider mb-3">
              Kit Tier Ratings Breakdown
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {kits.map((kit) => {
                const grade = player.kits[kit.id] || (kit.id === 'uhc' ? player.kits.gapple : undefined) || '???';
                return (
                  <div
                    key={kit.id}
                    className="p-2.5 rounded bg-[#121422] border border-[#21253a] flex flex-col items-center text-center"
                  >
                    <KitBadge kitId={kit.id} grade={grade} size="md" />
                    <span className="text-[11px] font-medium text-slate-300 mt-1 truncate w-full">
                      {kit.name}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Owner Quick Crown Button */}
          {currentRole === 'owner' && rank !== 1 && (
            <div className="pt-2">
              <button
                onClick={() => {
                  onSetAsNumberOne(player);
                  onClose();
                }}
                className="mc-button w-full py-2.5 px-4 rounded text-xs font-pixel text-slate-950 bg-amber-400 hover:bg-amber-300 border-amber-200 flex items-center justify-center gap-2 cursor-pointer font-bold shadow-md"
              >
                <Crown className="w-4 h-4 fill-slate-950 text-slate-950" />
                <span>Make {player.username} the #1 Player (Owner Power)</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

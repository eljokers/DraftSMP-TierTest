import React, { useState } from 'react';
import { KitType, TierGrade } from '../types/playerTiers';

interface KitBadgeProps {
  kitId: KitType;
  grade: TierGrade;
  size?: 'sm' | 'md' | 'lg';
}

export const KitBadge: React.FC<KitBadgeProps> = ({ kitId, grade }) => {
  const [showTooltip, setShowTooltip] = useState(false);

  // Grade color matching image_7a6db2a2.png & image_ea98533e.png
  const getGradeStyle = () => {
    if (grade === '???') {
      return {
        textColor: 'text-[#565f79]',
        borderColor: 'border-[#3f4760]',
        label: '???',
      };
    }

    if (grade.includes('1')) {
      // Tier 1 -> Bright Golden Yellow with yellow underline
      return {
        textColor: 'text-[#facc15]',
        borderColor: 'border-[#facc15]',
        label: grade,
      };
    }

    if (grade.includes('2')) {
      // Tier 2 -> White/Silver with silver underline
      return {
        textColor: 'text-[#e2e8f0]',
        borderColor: 'border-[#cbd5e1]',
        label: grade,
      };
    }

    if (grade.includes('3')) {
      // Tier 3 -> Vibrant Orange with orange underline (exact image_7a6db2a2 style!)
      return {
        textColor: 'text-[#f97316]',
        borderColor: 'border-[#f97316]',
        label: grade,
      };
    }

    if (grade.includes('4')) {
      // Tier 4 -> Cyan
      return {
        textColor: 'text-[#38bdf8]',
        borderColor: 'border-[#38bdf8]',
        label: grade,
      };
    }

    if (grade.includes('5')) {
      // Tier 5 -> Emerald Green
      return {
        textColor: 'text-[#10b981]',
        borderColor: 'border-[#10b981]',
        label: grade,
      };
    }

    if (grade.includes('6')) {
      // Tier 6 -> Vibrant Fuchsia/Purple
      return {
        textColor: 'text-[#d946ef]',
        borderColor: 'border-[#d946ef]',
        label: grade,
      };
    }

    return {
      textColor: 'text-[#f97316]',
      borderColor: 'border-[#f97316]',
      label: grade,
    };
  };

  const gradeStyle = getGradeStyle();

  const getKitInfo = () => {
    switch (kitId) {
      case 'smp':
        return { name: 'SMP (Ender Pearl)', desc: 'Pearl clutching & trajectory mechanics' };
      case 'shield':
        return { name: 'Shield PvP', desc: '100% damage block & axe timing counter-strikes' };
      case 'netherite_chest':
        return { name: 'Netherite Pot', desc: 'Splash Speed II Netherite armor dueling' };
      case 'gapple':
      case 'uhc':
        return { name: 'UHC', desc: 'Golden apple absorption pacing & natural health regeneration off' };
      case 'diamond_chest':
        return { name: 'Diamond SMP', desc: 'Classic 1.21 Diamond armor combat' };
      case 'cart':
        return { name: 'Cart (TNT Minecart)', desc: 'High-velocity rail detonation & blast dodging' };
      case 'mace':
        return { name: 'Mace (1.21 Heavy Core)', desc: 'Falling smash damage multiplier & wind burst chaining' };
      case 'sword':
        return { name: 'Diamond Sword', desc: 'Sprint resets, critical combos & W-tap spacing' };
      case 'crystal':
        return { name: 'Crystal (End Crystal)', desc: 'Obsidian anchor & double crystal detonations' };
      case 'bow':
        return { name: 'Bow & Spear', desc: 'Long-range headshots & punch bow maneuvering' };
      default:
        return { name: 'Custom Kit', desc: 'Competitive Minecraft PvP format' };
    }
  };

  const kitInfo = getKitInfo();

  // 9 Authentic Minecraft PvP Kits with uploaded transparent pixel-art assets
  const renderItemSprite = () => {
    const kitIconMap: Record<string, { src: string; alt: string; glow: string }> = {
      smp: {
        src: '/assets/aistudio/image__7__6b40216b.png',
        alt: 'SMP Ender Pearl',
        glow: 'drop-shadow-[0_0_8px_rgba(16,185,129,0.7)]',
      },
      shield: {
        src: '/assets/aistudio/image_8a4359eb.png',
        alt: 'Shield',
        glow: 'drop-shadow-[0_0_8px_rgba(202,138,4,0.6)]',
      },
      netherite_chest: {
        src: '/assets/aistudio/image__1__8ec55bbe.png',
        alt: 'Netherite Pot',
        glow: 'drop-shadow-[0_0_8px_rgba(120,113,108,0.7)]',
      },
      uhc: {
        src: '/assets/aistudio/image__4__ba483a1b.png',
        alt: 'UHC',
        glow: 'drop-shadow-[0_0_10px_rgba(250,204,21,0.85)]',
      },
      gapple: {
        src: '/assets/aistudio/image__4__ba483a1b.png',
        alt: 'UHC',
        glow: 'drop-shadow-[0_0_10px_rgba(250,204,21,0.85)]',
      },
      diamond_chest: {
        src: '/assets/aistudio/image__6__a307b038.png',
        alt: 'Diamond SMP',
        glow: 'drop-shadow-[0_0_8px_rgba(6,182,212,0.8)]',
      },
      cart: {
        src: '/assets/aistudio/image__5__efee6034.png',
        alt: 'Cart TNT',
        glow: 'drop-shadow-[0_0_8px_rgba(239,68,68,0.8)]',
      },
      mace: {
        src: '/assets/aistudio/image__3__2d6d70d5.png',
        alt: 'Mace',
        glow: 'drop-shadow-[0_0_8px_rgba(249,115,22,0.8)]',
      },
      sword: {
        src: '/assets/aistudio/image__8__8184cbe4.png',
        alt: 'Diamond Sword',
        glow: 'drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]',
      },
      crystal: {
        src: '/assets/aistudio/image__9__94a32411.png',
        alt: 'End Crystal',
        glow: 'drop-shadow-[0_0_8px_rgba(192,132,252,0.8)]',
      },
    };

    const config = kitIconMap[kitId];
    if (config) {
      return (
        <img
          src={config.src}
          alt={config.alt}
          className={`w-7 h-7 sm:w-8 sm:h-8 object-contain filter ${config.glow} transition-transform duration-150`}
          style={{ imageRendering: 'pixelated' }}
          loading="lazy"
        />
      );
    }

    return <span className="text-sm">⚔️</span>;
  };

  return (
    <div
      className="relative select-none"
      onMouseEnter={() => setShowTooltip(true)}
      onMouseLeave={() => setShowTooltip(false)}
    >
      {/* Box Container matching image_7a6db2a2.png and image_ea98533e.png - Scaled up for clarity */}
      <div
        className={`
          w-11 sm:w-12 h-16 sm:h-[70px] rounded-lg bg-black/45 backdrop-blur-sm border border-amber-500/25 hover:border-amber-400/80
          flex flex-col items-center justify-between p-1.5 transition-all duration-150 cursor-pointer
          hover:scale-105 hover:bg-black/65 hover:shadow-[0_0_14px_rgba(245,158,11,0.25)]
        `}
      >
        {/* Top: Sprite */}
        <div className="flex-1 flex items-center justify-center w-full">
          {renderItemSprite()}
        </div>

        {/* Hairline Divider */}
        <div className="w-full h-[1px] bg-[#1a1e33] my-0.5" />

        {/* Bottom: Grade Label with Underline Bar */}
        <div className="w-full flex flex-col items-center justify-end pb-0.5">
          <span
            className={`font-pixel text-[11px] leading-tight font-bold tracking-tight ${gradeStyle.textColor}`}
          >
            {gradeStyle.label}
          </span>
          {/* Centered Underline Bar matching image_7a6db2a2 */}
          <div className={`w-6 h-[2px] mt-0.5 border-b-2 ${gradeStyle.borderColor}`} />
        </div>
      </div>

      {/* Floating Hover Tooltip */}
      {showTooltip && (
        <div
          className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-2 rounded-md bg-[#080912]/98 border border-[#3b4263] shadow-2xl pointer-events-none z-50 animate-in fade-in duration-100"
          style={{
            boxShadow: '0 8px 24px rgba(0,0,0,0.9), 0 0 1px rgba(255,255,255,0.2)',
          }}
        >
          <div className="flex items-center justify-between gap-1 mb-1 border-b border-[#1c2035] pb-1">
            <span className="font-pixel text-[11px] text-slate-100 font-bold truncate">
              {kitInfo.name}
            </span>
            <span
              className={`font-pixel text-[10px] px-1 rounded font-bold ${gradeStyle.textColor} bg-black/50`}
            >
              {grade}
            </span>
          </div>

          <div className="text-[10px] text-slate-400 leading-tight">
            {grade === '???' ? (
              <span className="text-slate-500 italic">Not tested / Unranked (???)</span>
            ) : (
              <span>{kitInfo.desc}</span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

import React, { useState } from 'react';

interface PlayerAvatarProps {
  username: string;
  type?: 'head' | 'body';
  size?: number;
  className?: string;
}

export const PlayerAvatar: React.FC<PlayerAvatarProps> = ({
  username,
  type = 'head',
  size = 48,
  className = '',
}) => {
  const [hasError, setHasError] = useState(false);

  // If unranked or empty, show three question marks ??? as requested
  if (username === '???' || !username || username.toLowerCase() === 'unranked') {
    return (
      <div
        className={`flex items-center justify-center font-pixel rounded-lg bg-[#10121f] border border-[#23273e] text-amber-400 font-bold select-none shadow-inner ${className}`}
        style={{
          width: size,
          height: type === 'body' ? size * 1.8 : size,
          fontSize: type === 'body' ? size * 0.5 : size * 0.45,
        }}
      >
        ???
      </div>
    );
  }

  // Generate skin URLs
  const headUrl = `https://mc-heads.net/avatar/${encodeURIComponent(username)}/100`;
  const bodyUrl = `https://mc-heads.net/body/${encodeURIComponent(username)}/right`;

  if (hasError) {
    // Pixel avatar fallback
    return (
      <div
        className={`flex items-center justify-center font-pixel rounded bg-[#1e202e] border border-[#2d3045] text-amber-400 select-none ${className}`}
        style={{ width: size, height: type === 'body' ? size * 1.8 : size, fontSize: size * 0.4 }}
      >
        {username.slice(0, 2).toUpperCase()}
      </div>
    );
  }

  if (type === 'body') {
    return (
      <img
        src={bodyUrl}
        alt={`${username}'s 3D skin`}
        onError={() => setHasError(true)}
        className={`object-contain select-none pointer-events-none drop-shadow-md ${className}`}
        style={{ height: size * 1.8, maxHeight: 180 }}
        loading="lazy"
      />
    );
  }

  return (
    <img
      src={headUrl}
      alt={`${username}'s avatar`}
      onError={() => setHasError(true)}
      className={`rounded select-none pointer-events-none border border-[#2b2d40] ${className}`}
      style={{ width: size, height: size }}
      loading="lazy"
    />
  );
};

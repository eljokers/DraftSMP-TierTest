import React from 'react';
import { KitDefinition, KitType } from '../types/playerTiers';
import { ChevronRight } from 'lucide-react';

interface KitsListViewProps {
  kits: KitDefinition[];
  onSelectKit: (kitId: KitType) => void;
}

export const KitsListView: React.FC<KitsListViewProps> = ({ kits, onSelectKit }) => {
  const renderKitIcon = (id: KitType) => {
    const kitIconMap: Record<string, { src: string; alt: string; glow: string }> = {
      smp: {
        src: '/assets/aistudio/image__7__6b40216b.png',
        alt: 'SMP Ender Pearl',
        glow: 'drop-shadow-[0_0_8px_rgba(16,185,129,0.7)]',
      },
      shield: {
        src: '/assets/aistudio/image_8a4359eb.png',
        alt: 'Shield',
        glow: 'drop-shadow-[0_0_8px_rgba(202,138,4,0.6)]',
      },
      netherite_chest: {
        src: '/assets/aistudio/image__1__8ec55bbe.png',
        alt: 'Netherite Pot',
        glow: 'drop-shadow-[0_0_8px_rgba(120,113,108,0.7)]',
      },
      uhc: {
        src: '/assets/aistudio/image__4__ba483a1b.png',
        alt: 'UHC',
        glow: 'drop-shadow-[0_0_10px_rgba(250,204,21,0.85)]',
      },
      gapple: {
        src: '/assets/aistudio/image__4__ba483a1b.png',
        alt: 'UHC',
        glow: 'drop-shadow-[0_0_10px_rgba(250,204,21,0.85)]',
      },
      diamond_chest: {
        src: '/assets/aistudio/image__6__a307b038.png',
        alt: 'Diamond SMP',
        glow: 'drop-shadow-[0_0_8px_rgba(6,182,212,0.8)]',
      },
      cart: {
        src: '/assets/aistudio/image__5__efee6034.png',
        alt: 'Cart TNT',
        glow: 'drop-shadow-[0_0_8px_rgba(239,68,68,0.8)]',
      },
      mace: {
        src: '/assets/aistudio/image__3__2d6d70d5.png',
        alt: 'Mace',
        glow: 'drop-shadow-[0_0_8px_rgba(249,115,22,0.8)]',
      },
      sword: {
        src: '/assets/aistudio/image__8__8184cbe4.png',
        alt: 'Diamond Sword',
        glow: 'drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]',
      },
      crystal: {
        src: '/assets/aistudio/image__9__94a32411.png',
        alt: 'End Crystal',
        glow: 'drop-shadow-[0_0_8px_rgba(192,132,252,0.8)]',
      },
    };

    const config = kitIconMap[id];
    if (config) {
      return (
        <img
          src={config.src}
          alt={config.alt}
          className={`w-7 h-7 object-contain filter ${config.glow}`}
          style={{ imageRendering: 'pixelated' }}
          loading="lazy"
        />
      );
    }

    return <span>⚔️</span>;
  };

  return (
    <div className="w-full bg-black/40 backdrop-blur-md border border-amber-500/25 rounded-xl overflow-hidden shadow-2xl">
      {/* Header matching Image 1: KIT on left, LEADERBOARD on right */}
      <div className="flex items-center justify-between px-6 py-3 bg-black/40 border-b border-amber-500/20 text-xs font-pixel text-amber-200/80 uppercase tracking-widest select-none">
        <span>Kit</span>
        <span>Leaderboard</span>
      </div>

      {/* Rows */}
      <div className="divide-y divide-amber-500/10">
        {kits.map((kit) => (
          <div
            key={kit.id}
            onClick={() => onSelectKit(kit.id)}
            className="flex items-center justify-between px-6 py-4 hover:bg-amber-500/10 transition-colors cursor-pointer group"
          >
            {/* Left: Icon + Kit Name */}
            <div className="flex items-center gap-4">
              <div className="w-10 h-10 rounded-lg bg-black/50 border border-amber-500/30 flex items-center justify-center group-hover:scale-110 transition-transform shadow-inner">
                {renderKitIcon(kit.id)}
              </div>
              <div>
                <span className="font-pixel text-sm text-slate-100 group-hover:text-emerald-400 transition-colors block">
                  {kit.name}
                </span>
                <span className="text-[11px] text-slate-500 hidden sm:block">
                  {kit.description}
                </span>
              </div>
            </div>

            {/* Right: View tiers > */}
            <div className="flex items-center gap-1.5 text-xs text-slate-400 group-hover:text-slate-200 transition-colors">
              <span>View tiers</span>
              <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-emerald-400 group-hover:translate-x-0.5 transition-all" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

import React, { useState, useRef, useEffect } from 'react';
import { UserRole, StaffMember, AuthUser } from '../types/playerTiers';
import { Crown, Swords, Shield, Lock, Unlock, FileText, LogIn, LogOut, ChevronDown, Sparkles } from 'lucide-react';
import { PlayerAvatar } from './PlayerAvatar';

export type NavTab = 'home' | 'tiers' | 'kits' | 'staff' | 'dashboard';

interface NavigationProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  isDashboardUnlocked: boolean;
  onLockDashboard?: () => void;
  staff: StaffMember[];
  onOpenApply?: () => void;
  currentUser: AuthUser | null;
  onOpenAuth: () => void;
  onLogout: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeTab,
  onTabChange,
  currentRole,
  onRoleChange,
  isDashboardUnlocked,
  staff,
  onOpenApply,
  currentUser,
  onOpenAuth,
  onLogout,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-black/40 backdrop-blur-md border-b border-amber-500/20 px-4 sm:px-8 py-3 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Left: Brand Identity */}
        <div className="flex items-center gap-6">
          <button
            type="button"
            onClick={() => onTabChange('tiers')}
            className="flex items-center gap-2.5 text-left cursor-pointer group"
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-500/20 to-orange-600/30 border border-amber-500/40 flex items-center justify-center shadow-[0_0_12px_rgba(245,158,11,0.25)] group-hover:scale-105 transition-transform">
              <Crown className="w-4 h-4 text-amber-400 fill-amber-400" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-pixel text-sm sm:text-base text-amber-400 font-bold tracking-wider">
                  DraftSMP
                </span>
                <span className="font-pixel text-sm sm:text-base text-slate-100 font-bold tracking-wider">
                  - TierTest
                </span>
              </div>
              <span className="text-[10px] text-amber-400/80 block -mt-0.5 tracking-tight font-medium">
                Official Competitive Tierlist
              </span>
            </div>
          </button>

          {/* Navigation Links - Matching Attachment 2 Reference */}
          <nav className="hidden md:flex items-center gap-6 text-xs sm:text-sm font-pixel">
            {/* Tiers (Main Hub) */}
            <button
              type="button"
              onClick={() => onTabChange('tiers')}
              className={`py-1.5 flex items-center gap-1.5 transition-colors cursor-pointer relative ${
                activeTab === 'tiers' || activeTab === 'home'
                  ? 'text-orange-400 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Crown className={`w-3.5 h-3.5 ${activeTab === 'tiers' || activeTab === 'home' ? 'text-orange-400 fill-orange-400' : 'text-slate-400'}`} />
              <span>Tiers</span>
              {(activeTab === 'tiers' || activeTab === 'home') && (
                <span className="absolute bottom-[-13px] left-0 right-0 h-[2.5px] bg-red-600 shadow-[0_0_8px_rgba(239,68,68,0.8)]" />
              )}
            </button>

            {/* Kits */}
            <button
              type="button"
              onClick={() => onTabChange('kits')}
              className={`py-1.5 flex items-center gap-1.5 transition-colors cursor-pointer relative ${
                activeTab === 'kits'
                  ? 'text-orange-400 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Swords className="w-3.5 h-3.5 text-slate-400" />
              <span>Kits</span>
              {activeTab === 'kits' && (
                <span className="absolute bottom-[-13px] left-0 right-0 h-[2.5px] bg-red-600 shadow-[0_0_8px_rgba(239,68,68,0.8)]" />
              )}
            </button>

            {/* Staff List */}
            <button
              type="button"
              onClick={() => onTabChange('staff')}
              className={`py-1.5 flex items-center gap-1.5 transition-colors cursor-pointer relative ${
                activeTab === 'staff'
                  ? 'text-orange-400 font-bold'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Shield className="w-3.5 h-3.5 text-slate-400" />
              <span>Staff ({staff.length})</span>
              {activeTab === 'staff' && (
                <span className="absolute bottom-[-13px] left-0 right-0 h-[2.5px] bg-red-600 shadow-[0_0_8px_rgba(239,68,68,0.8)]" />
              )}
            </button>

            {/* Staff Dashboard (Only for Staff or Owner) */}
            {(currentRole === 'owner' || currentRole === 'staff') && (
              <button
                type="button"
                onClick={() => onTabChange('dashboard')}
                className={`py-1.5 flex items-center gap-1.5 transition-colors cursor-pointer relative ${
                  activeTab === 'dashboard'
                    ? 'text-amber-400 font-bold'
                    : 'text-slate-400 hover:text-amber-300'
                }`}
              >
                <Shield className="w-3.5 h-3.5 text-amber-400" />
                <span>Dashboard</span>
                {isDashboardUnlocked ? (
                  <Unlock className="w-3 h-3 text-emerald-400" />
                ) : (
                  <Lock className="w-3 h-3 text-amber-500" />
                )}
                {activeTab === 'dashboard' && (
                  <span className="absolute bottom-[-13px] left-0 right-0 h-[2.5px] bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.8)]" />
                )}
              </button>
            )}
          </nav>
        </div>

        {/* Right: Actions & User Info */}
        <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
          {/* Apply Button */}
          {onOpenApply && (
            <button
              type="button"
              onClick={onOpenApply}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-amber-500/30 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 text-xs font-pixel font-semibold transition-all cursor-pointer shadow-sm hover:scale-105"
            >
              <FileText className="w-3.5 h-3.5 text-amber-400" />
              <span>Staff Apply</span>
            </button>
          )}

          {/* User Account Section */}
          {currentUser ? (
            <div className="flex items-center gap-2 bg-[#0d0f1c] border border-[#22273e] rounded-lg p-1 pl-1.5 pr-2 shadow-sm">
              <div className="w-6 h-6 rounded bg-[#151728] border border-[#2d3250] flex items-center justify-center shrink-0 overflow-hidden">
                <PlayerAvatar username={currentUser.username} type="head" size={24} />
              </div>
              <div className="text-left leading-tight hidden sm:block">
                <span className="font-pixel text-[11px] text-slate-100 block font-bold truncate max-w-[85px]">
                  {currentUser.username}
                </span>
                <span className="text-[9px] text-amber-400 font-pixel uppercase block">
                  {currentUser.role}
                </span>
              </div>
              <button
                type="button"
                onClick={onLogout}
                className="p-1 rounded text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 cursor-pointer ml-1"
                title="Log out"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={onOpenAuth}
              className="mc-button px-3 py-1.5 rounded-lg text-xs font-pixel text-slate-950 bg-amber-400 hover:bg-amber-300 border-amber-200 font-bold flex items-center gap-1.5 cursor-pointer shadow-md"
            >
              <LogIn className="w-3.5 h-3.5 text-slate-950" />
              <span>Login</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};


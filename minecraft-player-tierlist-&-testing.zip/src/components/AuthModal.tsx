import React, { useState } from 'react';
import { AuthUser } from '../types/playerTiers';
import { registerUser, loginUser } from '../services/firestoreService';
import { PlayerAvatar } from './PlayerAvatar';
import { 
  Shield, 
  Crown, 
  Lock, 
  User, 
  MessageSquare, 
  KeyRound, 
  Eye, 
  EyeOff, 
  X, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle,
  LogIn,
  UserPlus,
  ArrowRight
} from 'lucide-react';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: (user: AuthUser) => void;
  initialMode?: 'register' | 'login';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onAuthSuccess,
  initialMode = 'register',
}) => {
  const [mode, setMode] = useState<'register' | 'login'>(initialMode);
  const [registerMethod, setRegisterMethod] = useState<'minecraft' | 'discord'>('discord');

  // Form Fields
  const [minecraftUsername, setMinecraftUsername] = useState('');
  const [discordTag, setDiscordTag] = useState('');
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  // Status
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!minecraftUsername.trim()) {
      setErrorMsg('Please enter your Minecraft in-game username (IGN).');
      return;
    }
    if (registerMethod === 'discord' && !discordTag.trim()) {
      setErrorMsg('Please enter your Discord username or tag.');
      return;
    }
    if (password.length < 4) {
      setErrorMsg('Password must be at least 4 characters long.');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMsg('Passwords do not match. Please re-enter.');
      return;
    }

    setLoading(true);
    try {
      const user = await registerUser({
        username: minecraftUsername.trim(),
        discord: discordTag.trim() || undefined,
        password,
        registeredWith: registerMethod,
      });

      setSuccessMsg(`Welcome, ${user.username}! Account created successfully.`);
      setTimeout(() => {
        onAuthSuccess(user);
        onClose();
      }, 700);
    } catch (err: any) {
      setErrorMsg(err.message || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!loginIdentifier.trim()) {
      setErrorMsg('Please enter your Minecraft Username or Discord tag.');
      return;
    }
    if (!password) {
      setErrorMsg('Please enter your password.');
      return;
    }

    setLoading(true);
    try {
      const user = await loginUser(loginIdentifier.trim(), password);
      setSuccessMsg(`Welcome back, ${user.username}!`);
      setTimeout(() => {
        onAuthSuccess(user);
        onClose();
      }, 600);
    } catch (err: any) {
      setErrorMsg(err.message || 'Login failed. Check your username/discord or password.');
    } finally {
      setLoading(false);
    }
  };

  const previewIgn = (mode === 'register' ? minecraftUsername : loginIdentifier).trim();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md rounded-2xl bg-[#0c0e18] border-2 border-orange-500/40 shadow-[0_0_50px_rgba(249,115,22,0.25)] overflow-hidden">
        {/* Top Glow Accent */}
        <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500" />
        
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors cursor-pointer z-10"
          title="Continue as Guest / إغلاق للمتابعة كزائر"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="p-6 sm:p-7 space-y-5">
          {/* Header */}
          <div className="text-center space-y-1.5">
            <div className="w-12 h-12 rounded-xl bg-orange-500/20 border border-orange-500/40 flex items-center justify-center mx-auto shadow-inner">
              <Crown className="w-6 h-6 text-orange-400 fill-orange-400" />
            </div>
            <h2 className="font-pixel text-lg sm:text-xl text-slate-100 font-bold tracking-wide">
              {mode === 'register' ? 'Register Account (إنشاء حساب)' : 'Staff & Player Login (دخول)'}
            </h2>
            <p className="text-xs text-slate-400">
              {mode === 'register'
                ? 'Join the DraftSMP-TierTest community & track your rank'
                : 'Login with your Minecraft IGN or Discord handle'}
            </p>
          </div>

          {/* Mode Switch Tabs (Register First as requested) */}
          <div className="grid grid-cols-2 p-1 bg-[#121526] rounded-xl border border-[#222744]">
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setErrorMsg(null);
              }}
              className={`py-2 text-xs font-pixel rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                mode === 'register'
                  ? 'bg-orange-500 text-slate-950 font-bold shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Register (حساب جديد)</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setMode('login');
                setErrorMsg(null);
              }}
              className={`py-2 text-xs font-pixel rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
                mode === 'login'
                  ? 'bg-orange-500 text-slate-950 font-bold shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Login (تسجيل الدخول)</span>
            </button>
          </div>

          {/* Error & Success Messages */}
          {errorMsg && (
            <div className="p-3 rounded-lg bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3 rounded-lg bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* ================= REGISTER FORM ================= */}
          {mode === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              {/* Register Method Switcher */}
              <div className="space-y-1">
                <label className="text-[11px] font-pixel text-slate-400 uppercase block">
                  Choose Registration Method:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRegisterMethod('discord')}
                    className={`p-2.5 rounded-lg border text-xs font-pixel flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      registerMethod === 'discord'
                        ? 'bg-[#5865F2]/20 border-[#5865F2] text-indigo-200 shadow-[0_0_12px_rgba(88,101,242,0.3)]'
                        : 'bg-[#121526] border-[#222744] text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="w-3.5 h-3.5 rounded-full bg-[#5865F2] flex items-center justify-center">
                      <MessageSquare className="w-2 h-2 text-white" />
                    </div>
                    <span>By Discord</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRegisterMethod('minecraft')}
                    className={`p-2.5 rounded-lg border text-xs font-pixel flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      registerMethod === 'minecraft'
                        ? 'bg-emerald-500/20 border-emerald-500 text-emerald-200 shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                        : 'bg-[#121526] border-[#222744] text-slate-400 hover:text-white'
                    }`}
                  >
                    <User className="w-3.5 h-3.5 text-emerald-400" />
                    <span>By Minecraft IGN</span>
                  </button>
                </div>
              </div>

              {/* Discord Tag (Primary if method is discord, optional if method is minecraft) */}
              {registerMethod === 'discord' && (
                <div>
                  <label className="block text-slate-300 font-pixel text-xs mb-1">
                    Discord Username / Tag * (اسم الديسكورد)
                  </label>
                  <div className="relative">
                    <div className="w-4 h-4 rounded-full bg-[#5865F2] flex items-center justify-center absolute left-3 top-1/2 -translate-y-1/2">
                      <MessageSquare className="w-2.5 h-2.5 text-white" />
                    </div>
                    <input
                      type="text"
                      required
                      value={discordTag}
                      onChange={(e) => setDiscordTag(e.target.value)}
                      placeholder="e.g. yourname or User#0000"
                      className="w-full pl-9 pr-3 py-2 bg-[#121526] border border-[#262b48] rounded-lg text-slate-100 font-mono text-xs focus:outline-none focus:border-[#5865F2]"
                    />
                  </div>
                </div>
              )}

              {/* Minecraft Username (IGN) */}
              <div>
                <label className="block text-slate-300 font-pixel text-xs mb-1">
                  Minecraft In-Game Name (IGN) * (اسمك في اللعبة)
                </label>
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <User className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      required
                      value={minecraftUsername}
                      onChange={(e) => setMinecraftUsername(e.target.value)}
                      placeholder="e.g. Dream, JokingDK, ViperPvP"
                      className="w-full pl-9 pr-3 py-2 bg-[#121526] border border-[#262b48] rounded-lg text-slate-100 font-pixel text-xs focus:outline-none focus:border-orange-500"
                    />
                  </div>
                  {previewIgn && (
                    <div className="w-9 h-9 rounded-lg bg-[#141729] border border-[#2b3152] flex items-center justify-center shrink-0 shadow-inner">
                      <PlayerAvatar username={previewIgn} type="head" size={28} />
                    </div>
                  )}
                </div>
                <span className="text-[10px] text-slate-500 mt-0.5 block">
                  Your official Minecraft skin will be automatically loaded and displayed.
                </span>
              </div>

              {registerMethod === 'minecraft' && (
                <div>
                  <label className="block text-slate-300 font-pixel text-xs mb-1">
                    Discord Username (اختياري / Optional)
                  </label>
                  <div className="relative">
                    <div className="w-4 h-4 rounded-full bg-[#5865F2] flex items-center justify-center absolute left-3 top-1/2 -translate-y-1/2">
                      <MessageSquare className="w-2.5 h-2.5 text-white" />
                    </div>
                    <input
                      type="text"
                      value={discordTag}
                      onChange={(e) => setDiscordTag(e.target.value)}
                      placeholder="e.g. User#0000"
                      className="w-full pl-9 pr-3 py-2 bg-[#121526] border border-[#262b48] rounded-lg text-slate-100 font-mono text-xs focus:outline-none focus:border-indigo-500"
                    />
                  </div>
                </div>
              )}

              {/* Password */}
              <div>
                <label className="block text-slate-300 font-pixel text-xs mb-1">
                  Password * (كلمة المرور)
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="At least 4 characters"
                    className="w-full pl-9 pr-9 py-2 bg-[#121526] border border-[#262b48] rounded-lg text-slate-100 font-mono text-xs focus:outline-none focus:border-orange-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              {/* Confirm Password */}
              <div>
                <label className="block text-slate-300 font-pixel text-xs mb-1">
                  Confirm Password * (تأكيد كلمة المرور)
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Repeat password"
                    className="w-full pl-9 pr-3 py-2 bg-[#121526] border border-[#262b48] rounded-lg text-slate-100 font-mono text-xs focus:outline-none focus:border-orange-500"
                  />
                </div>
              </div>

              {/* Submit Register Button */}
              <button
                type="submit"
                disabled={loading}
                className="mc-button w-full py-2.5 rounded-xl font-pixel text-xs text-slate-950 bg-orange-500 hover:bg-orange-400 border-orange-300 font-bold flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-50"
              >
                {loading ? (
                  <span className="animate-spin">⏳</span>
                ) : (
                  <>
                    <UserPlus className="w-4 h-4 text-slate-950" />
                    <span>Create Account &amp; Enter (تسجيل)</span>
                  </>
                )}
              </button>
            </form>
          )}

          {/* ================= LOGIN FORM ================= */}
          {mode === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              {/* Login Identifier (Username OR Discord) */}
              <div>
                <label className="block text-slate-300 font-pixel text-xs mb-1">
                  Minecraft Username OR Discord Tag * (اسم اللاعب أو الديسكورد)
                </label>
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <User className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      required
                      value={loginIdentifier}
                      onChange={(e) => setLoginIdentifier(e.target.value)}
                      placeholder="e.g. Dream or Username#0000"
                      className="w-full pl-9 pr-3 py-2 bg-[#121526] border border-[#262b48] rounded-lg text-slate-100 font-pixel text-xs focus:outline-none focus:border-orange-500"
                    />
                  </div>
                  {previewIgn && (
                    <div className="w-9 h-9 rounded-lg bg-[#141729] border border-[#2b3152] flex items-center justify-center shrink-0 shadow-inner">
                      <PlayerAvatar username={previewIgn} type="head" size={28} />
                    </div>
                  )}
                </div>
              </div>

              {/* Password */}
              <div>
                <label className="block text-slate-300 font-pixel text-xs mb-1">
                  Password * (كلمة المرور)
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter account password"
                    className="w-full pl-9 pr-9 py-2 bg-[#121526] border border-[#262b48] rounded-lg text-slate-100 font-mono text-xs focus:outline-none focus:border-orange-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300"
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
                <div className="mt-1 text-[10px] text-slate-500 flex justify-between">
                  <span>Owner master key: mcpvp.com</span>
                  <button
                    type="button"
                    onClick={() => setMode('register')}
                    className="text-orange-400 hover:underline cursor-pointer"
                  >
                    Need an account? Register
                  </button>
                </div>
              </div>

              {/* Submit Login Button */}
              <button
                type="submit"
                disabled={loading}
                className="mc-button w-full py-2.5 rounded-xl font-pixel text-xs text-slate-950 bg-orange-500 hover:bg-orange-400 border-orange-300 font-bold flex items-center justify-center gap-2 cursor-pointer shadow-lg disabled:opacity-50"
              >
                {loading ? (
                  <span className="animate-spin">⏳</span>
                ) : (
                  <>
                    <LogIn className="w-4 h-4 text-slate-950" />
                    <span>Login (تسجيل الدخول)</span>
                  </>
                )}
              </button>
            </form>
          )}

          {/* Footer: Guest Option */}
          <div className="pt-3 border-t border-[#1b1f33] text-center">
            <button
              type="button"
              onClick={onClose}
              className="text-xs text-slate-400 hover:text-orange-300 font-pixel inline-flex items-center gap-1 cursor-pointer transition-colors"
            >
              <span>Continue as Guest / تصفح كزائر</span>
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

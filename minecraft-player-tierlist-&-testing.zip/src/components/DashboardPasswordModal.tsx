import React, { useState } from 'react';
import { Lock, KeyRound, AlertCircle, X, ShieldCheck } from 'lucide-react';

interface DashboardPasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const DashboardPasswordModal: React.FC<DashboardPasswordModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password.trim().toLowerCase() === 'mcpvp.com') {
      setErrorMsg(null);
      setPassword('');
      onSuccess();
    } else {
      setErrorMsg('Incorrect password! Access denied.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-150">
      <div className="w-full max-w-md bg-[#0d0f1a] border-2 border-orange-500/50 rounded-xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-[#141728] border-b border-[#212640] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-orange-400" />
            <span className="font-pixel text-xs text-orange-300 font-bold uppercase tracking-wider">
              Staff Dashboard Locked
            </span>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded hover:bg-white/5 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="text-center space-y-2">
            <div className="w-12 h-12 rounded-full bg-orange-500/10 border border-orange-500/30 flex items-center justify-center mx-auto shadow-[0_0_16px_rgba(249,115,22,0.3)]">
              <KeyRound className="w-6 h-6 text-orange-400" />
            </div>
            <h3 className="font-pixel text-base text-slate-100">
              Enter Staff Password
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              This dashboard is restricted to authorized tier testers and administrators. Enter password to continue.
            </p>
          </div>

          {errorMsg && (
            <div className="p-2.5 rounded bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs font-pixel flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div>
            <label className="block text-slate-300 font-semibold uppercase text-xs mb-1.5">
              Dashboard Password
            </label>
            <input
              type="password"
              autoFocus
              required
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                if (errorMsg) setErrorMsg(null);
              }}
              placeholder="Enter staff password..."
              className="w-full px-3 py-2 bg-[#121526] border border-[#2b3050] rounded-lg text-slate-100 font-mono text-sm focus:outline-none focus:border-orange-500"
            />
            <span className="text-[10px] text-slate-500 mt-1 block">
              Authorized staff key required to access testing controls.
            </span>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded text-xs font-medium text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="mc-button px-5 py-2.5 rounded-lg text-xs font-pixel text-slate-950 bg-orange-500 hover:bg-orange-400 border-orange-300 font-bold flex items-center gap-2 cursor-pointer shadow-md"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>Unlock Dashboard</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

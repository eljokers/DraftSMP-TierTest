import React, { useState } from 'react';
import { StaffMember, UserRole } from '../types/playerTiers';
import { PlayerAvatar } from './PlayerAvatar';
import { Shield, Crown, Mail, Copy, Check, Search, MessageSquare, Plus, FileText } from 'lucide-react';

interface StaffListViewProps {
  staff: StaffMember[];
  currentRole: UserRole;
  onOpenDashboard: () => void;
  onOpenApply?: () => void;
  onToggleStaffStatus?: (staffId: string) => void;
}

export const StaffListView: React.FC<StaffListViewProps> = ({
  staff,
  currentRole,
  onOpenDashboard,
  onOpenApply,
  onToggleStaffStatus,
}) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'inactive'>('all');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredStaff = staff.filter((s) => {
    const q = search.toLowerCase();
    const matchesSearch =
      s.username.toLowerCase().includes(q) ||
      s.email.toLowerCase().includes(q) ||
      (s.discord && s.discord.toLowerCase().includes(q)) ||
      s.role.toLowerCase().includes(q);
    const matchesStatus =
      statusFilter === 'all' ||
      (statusFilter === 'active' && s.status === 'active') ||
      (statusFilter === 'inactive' && s.status === 'inactive');
    return matchesSearch && matchesStatus;
  });

  const activeCount = staff.filter((s) => s.status === 'active').length;
  const inactiveCount = staff.filter((s) => s.status === 'inactive').length;

  const getRoleStyle = (role: StaffMember['role']) => {
    switch (role) {
      case 'Owner':
        return {
          badge: 'bg-orange-500/20 text-orange-300 border-orange-500/50 shadow-[0_0_10px_rgba(249,115,22,0.3)]',
          border: 'border-orange-500/40 hover:border-orange-400',
          icon: <Crown className="w-3.5 h-3.5 text-orange-400 fill-orange-400" />,
        };
      case 'Head Tester':
        return {
          badge: 'bg-amber-500/20 text-amber-300 border-amber-500/50 shadow-[0_0_10px_rgba(245,158,11,0.2)]',
          border: 'border-amber-500/30 hover:border-amber-400',
          icon: <Shield className="w-3.5 h-3.5 text-amber-400" />,
        };
      case 'Tier Tester':
        return {
          badge: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40',
          border: 'border-cyan-500/30 hover:border-cyan-400',
          icon: <Shield className="w-3.5 h-3.5 text-cyan-400" />,
        };
      default:
        return {
          badge: 'bg-slate-700/30 text-slate-300 border-slate-600',
          border: 'border-[#222538] hover:border-slate-500',
          icon: <Shield className="w-3.5 h-3.5 text-slate-400" />,
        };
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-xl bg-black/35 backdrop-blur-md border border-amber-500/30 p-6 sm:p-8 text-center shadow-xl">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-32 bg-amber-500/10 blur-[60px] pointer-events-none" />

        <div className="relative z-10 max-w-xl mx-auto space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-pixel">
            <Shield className="w-3.5 h-3.5 text-amber-400" />
            <span>Staff Roster &amp; Testing Team</span>
          </div>

          <h2 className="font-pixel text-xl sm:text-2xl text-slate-100 font-bold tracking-wide">
            Official Staff List
          </h2>

          <p className="text-xs text-slate-400 leading-relaxed">
            Authorized tier testers and administrators. Contact staff via Discord or Gmail for tier testing inquiries.
          </p>

          <div className="pt-2 flex flex-wrap items-center justify-center gap-2.5">
            {onOpenApply && (
              <button
                type="button"
                onClick={onOpenApply}
                className="mc-button px-4 py-2 rounded text-xs font-pixel text-slate-950 bg-amber-400 hover:bg-amber-300 border-amber-200 cursor-pointer inline-flex items-center gap-1.5 font-bold shadow-md hover:scale-105 transition-all"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Staff TierTest Apply (تقديم تستر)</span>
              </button>
            )}

            {(currentRole === 'owner' || currentRole === 'staff') && (
              <button
                onClick={onOpenDashboard}
                className="mc-button px-4 py-2 rounded text-xs font-pixel text-white bg-orange-600 hover:bg-orange-500 border-orange-400 cursor-pointer inline-flex items-center gap-1.5 font-bold shadow-md"
              >
                <Shield className="w-3.5 h-3.5" />
                <span>Open Dashboard</span>
              </button>
            )}

            {currentRole === 'visitor' && (
              <a
                href="https://discord.gg/vyywzf6yX"
                target="_blank"
                rel="noopener noreferrer"
                className="mc-button px-4 py-2 rounded text-xs font-pixel text-white bg-[#5865F2] hover:bg-[#4752c4] border-indigo-400 cursor-pointer inline-flex items-center gap-2 font-bold shadow-md hover:scale-105 transition-all"
              >
                <MessageSquare className="w-3.5 h-3.5 text-white" />
                <span>Join Discord: discord.gg/vyywzf6yX</span>
              </a>
            )}
          </div>
        </div>
      </div>

      {/* Search Bar & Active Status Filter Tabs */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-black/35 backdrop-blur-md border border-amber-500/25 rounded-xl p-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-amber-400/70 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search staff by IGN, Gmail, Discord, or role..."
            className="w-full pl-9 pr-4 py-2 bg-black/40 border border-amber-500/25 rounded-lg text-xs text-slate-100 placeholder:text-slate-400 focus:outline-none focus:border-amber-400 transition-colors"
          />
        </div>

        {/* Status Filters: All, Active, Inactive */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            type="button"
            onClick={() => setStatusFilter('all')}
            className={`px-2.5 py-1 rounded text-xs font-pixel cursor-pointer border transition-colors ${
              statusFilter === 'all'
                ? 'bg-orange-500 text-slate-950 border-orange-300 font-bold'
                : 'bg-[#121424] text-slate-400 border-[#262b44] hover:text-slate-200'
            }`}
          >
            All ({staff.length})
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('active')}
            className={`px-2.5 py-1 rounded text-xs font-pixel cursor-pointer border flex items-center gap-1.5 transition-colors ${
              statusFilter === 'active'
                ? 'bg-emerald-500 text-slate-950 border-emerald-300 font-bold'
                : 'bg-[#121424] text-emerald-400 border-[#262b44] hover:bg-emerald-500/10'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Active ({activeCount})</span>
          </button>
          <button
            type="button"
            onClick={() => setStatusFilter('inactive')}
            className={`px-2.5 py-1 rounded text-xs font-pixel cursor-pointer border flex items-center gap-1.5 transition-colors ${
              statusFilter === 'inactive'
                ? 'bg-zinc-700 text-slate-100 border-zinc-500 font-bold'
                : 'bg-[#121424] text-zinc-400 border-[#262b44] hover:bg-zinc-800'
            }`}
          >
            <span className="w-2 h-2 rounded-full bg-zinc-500" />
            <span>Inactive ({inactiveCount})</span>
          </button>
        </div>
      </div>

      {/* Staff Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredStaff.map((member) => {
          const style = getRoleStyle(member.role);
          const gmailCopyKey = `gmail_${member.id}`;
          const discordCopyKey = `discord_${member.id}`;
          const isActive = member.status === 'active';

          return (
            <div
              key={member.id}
              className={`bg-black/40 backdrop-blur-md border ${style.border} rounded-xl p-5 flex flex-col justify-between shadow-lg transition-all duration-200 ${
                isActive
                  ? 'hover:-translate-y-1 hover:shadow-[0_8px_24px_rgba(245,158,11,0.2)]'
                  : 'opacity-75 hover:opacity-100 border-dashed'
              }`}
            >
              <div>
                {/* Top Section: Avatar & Name */}
                <div className="flex items-center gap-3.5 pb-4 border-b border-[#1b1f33]">
                  <div className="relative shrink-0">
                    <div className="w-12 h-12 rounded-lg bg-[#14172a] border border-[#2c3252] flex items-center justify-center overflow-hidden shadow-inner">
                      <PlayerAvatar username={member.username} type="head" size={44} />
                    </div>
                    {member.role === 'Owner' && (
                      <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-orange-500 border border-orange-300 flex items-center justify-center shadow-md">
                        <Crown className="w-3 h-3 text-slate-950 fill-slate-950" />
                      </span>
                    )}
                  </div>

                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-pixel text-sm sm:text-base text-slate-100 font-bold truncate">
                        {member.username}
                      </h3>
                      <span
                        className={`font-pixel text-[10px] px-2 py-0.5 rounded border font-semibold flex items-center gap-1 ${style.badge}`}
                      >
                        {style.icon}
                        <span>{member.role}</span>
                      </span>
                    </div>
                    <span className="text-[11px] text-slate-400 block mt-0.5">
                      Minecraft In-Game Name (IGN)
                    </span>
                  </div>
                </div>

                {/* Contact & Identifiers */}
                <div className="mt-4 space-y-2.5">
                  {/* Gmail Address */}
                  <div className="bg-[#121424] border border-[#20253d] rounded-lg p-2.5 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <Mail className="w-4 h-4 text-orange-400 shrink-0" />
                      <div className="min-w-0">
                        <span className="text-[10px] text-slate-400 block font-medium">
                          Staff Gmail
                        </span>
                        <span className="text-xs text-slate-200 font-mono truncate block">
                          {member.email}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleCopy(member.email, gmailCopyKey)}
                      className="p-1.5 rounded bg-[#1a1e34] hover:bg-orange-500/20 text-slate-400 hover:text-orange-300 border border-[#2b3152] transition-colors cursor-pointer shrink-0"
                      title="Copy Gmail"
                    >
                      {copiedId === gmailCopyKey ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>

                  {/* Discord Handle */}
                  <div className="bg-[#121424] border border-[#20253d] rounded-lg p-2.5 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-4 h-4 rounded-full bg-[#5865F2] flex items-center justify-center shrink-0">
                        <MessageSquare className="w-2.5 h-2.5 text-white" />
                      </div>
                      <div className="min-w-0">
                        <span className="text-[10px] text-indigo-400 block font-medium">
                          Discord Tag
                        </span>
                        <span className="text-xs text-slate-200 font-mono truncate block font-bold">
                          {member.discord ? `@${member.discord.replace(/^@/, '')}` : 'Not set'}
                        </span>
                      </div>
                    </div>

                    {member.discord && (
                      <button
                        type="button"
                        onClick={() => handleCopy(member.discord!, discordCopyKey)}
                        className="p-1.5 rounded bg-[#1a1e34] hover:bg-indigo-500/20 text-slate-400 hover:text-indigo-300 border border-[#2b3152] transition-colors cursor-pointer shrink-0"
                        title="Copy Discord Tag"
                      >
                        {copiedId === discordCopyKey ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    )}
                  </div>
                </div>
              </div>

              {/* Card Footer */}
              <div className="mt-4 pt-3 border-t border-[#191d30] flex items-center justify-between text-[11px]">
                {member.status === 'active' ? (
                  <span className="inline-flex items-center gap-1.5 text-emerald-400 font-pixel font-semibold">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_rgba(52,211,153,0.8)]" />
                    <span>Active Tester (نشط)</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 text-zinc-400 font-pixel font-semibold">
                    <span className="w-2 h-2 rounded-full bg-zinc-500" />
                    <span>Inactive (غير نشط)</span>
                  </span>
                )}

                <div className="flex items-center gap-2">
                  {currentRole === 'owner' && onToggleStaffStatus && (
                    <button
                      type="button"
                      onClick={() => onToggleStaffStatus(member.id)}
                      className={`px-2 py-0.5 rounded text-[10px] font-pixel border cursor-pointer transition-colors ${
                        member.status === 'active'
                          ? 'border-zinc-700 bg-zinc-800 text-zinc-300 hover:bg-zinc-700'
                          : 'border-emerald-500/40 bg-emerald-500/15 text-emerald-300 hover:bg-emerald-500/25'
                      }`}
                      title={member.status === 'active' ? 'Set as Inactive' : 'Set as Active'}
                    >
                      {member.status === 'active' ? 'Make Inactive' : 'Make Active'}
                    </button>
                  )}
                  <span className="font-mono text-slate-500 text-[10px]">Joined {member.joinedDate}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

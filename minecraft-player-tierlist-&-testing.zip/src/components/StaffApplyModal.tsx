import React, { useState } from 'react';
import { KitType, TierGrade, TierTestApplication, KitDefinition } from '../types/playerTiers';
import { PlayerAvatar } from './PlayerAvatar';
import { X, Send, ShieldCheck, MessageSquare, Mail, User, Swords, Clock, CheckCircle2, Globe, KeyRound, Lock } from 'lucide-react';

interface StaffApplyModalProps {
  isOpen: boolean;
  onClose: () => void;
  kits: KitDefinition[];
  onSubmitApplication: (app: TierTestApplication) => void;
  onBypassToDashboard?: () => void;
}

const TIER_GRADES: TierGrade[] = [
  'HT1', 'MT1', 'LT1',
  'HT2', 'MT2', 'LT2',
  'HT3', 'MT3', 'LT3',
  'HT4', 'MT4', 'LT4',
  'HT5', 'MT5', 'LT5',
  'HT6', 'MT6', 'LT6',
];

const OVERALL_TIERS = [
  'High Tier 1',
  'Mid Tier 1',
  'Low Tier 1',
  'High Tier 2',
  'Mid Tier 2',
  'Low Tier 2',
  'High Tier 3',
  'Mid Tier 3',
  'Low Tier 3',
  'High Tier 4',
  'Mid Tier 4',
  'Low Tier 4',
  'High Tier 5',
  'Mid Tier 5',
  'Low Tier 5',
  'High Tier 6',
  'Mid Tier 6',
  'Low Tier 6',
];

export const StaffApplyModal: React.FC<StaffApplyModalProps> = ({
  isOpen,
  onClose,
  kits,
  onSubmitApplication,
  onBypassToDashboard,
}) => {
  const [lang, setLang] = useState<'ar' | 'en'>('ar');
  const [submitted, setSubmitted] = useState(false);

  // Secret bypass modal state (Password: mcpvp.com)
  const [showSecretBypass, setShowSecretBypass] = useState(false);
  const [secretPass, setSecretPass] = useState('');
  const [secretError, setSecretError] = useState<string | null>(null);

  // Form Fields
  const [username, setUsername] = useState('');
  const [discord, setDiscord] = useState('');
  const [email, setEmail] = useState('');
  const [claimedTier, setClaimedTier] = useState<TierGrade>('HT2');
  const [overallTier, setOverallTier] = useState('High Tier 2');
  const [primaryKit, setPrimaryKit] = useState<KitType>('crystal');
  const [weeklyHours, setWeeklyHours] = useState('10-15 hours/week');
  const [experience, setExperience] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSecretBypassSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (secretPass.trim().toLowerCase() === 'mcpvp.com') {
      setShowSecretBypass(false);
      setSecretPass('');
      setSecretError(null);
      if (onBypassToDashboard) {
        onBypassToDashboard();
      }
    } else {
      setSecretError(lang === 'ar' ? 'كلمة المرور غير صحيحة!' : 'Incorrect bypass password!');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!username.trim()) {
      setErrorMsg(lang === 'ar' ? 'يرجى إدخال اسمك في ماينكرافت (IGN)' : 'Please enter your Minecraft In-Game Name (IGN)');
      return;
    }
    if (!discord.trim()) {
      setErrorMsg(lang === 'ar' ? 'يرجى إدخال حساب الديسكورد الخاص بك' : 'Please enter your Discord username');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setErrorMsg(lang === 'ar' ? 'يرجى إدخال بريد جيميل صحيح للتواصل' : 'Please enter a valid Gmail address');
      return;
    }
    if (!experience.trim()) {
      setErrorMsg(lang === 'ar' ? 'يرجى كتابة نبذة عن خبرتك وسبب التقديم' : 'Please describe your duels experience & why you want to test');
      return;
    }

    const newApp: TierTestApplication = {
      id: `app_${Date.now()}`,
      username: username.trim(),
      discord: discord.trim(),
      email: email.trim(),
      primaryKit,
      claimedTier,
      overallTier,
      weeklyHours,
      experience: experience.trim(),
      language: lang === 'ar' ? 'ar' : 'en',
      submittedDate: new Date().toISOString().split('T')[0],
      status: 'pending',
    };

    onSubmitApplication(newApp);
    setSubmitted(true);
  };

  const handleResetAndClose = () => {
    setSubmitted(false);
    setUsername('');
    setDiscord('');
    setEmail('');
    setExperience('');
    setErrorMsg(null);
    onClose();
  };

  const isAr = lang === 'ar';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-150">
      <div 
        dir={isAr ? 'rtl' : 'ltr'} 
        className="w-full max-w-xl max-h-[92vh] overflow-y-auto bg-[#0c0e17] border-2 border-orange-500/40 rounded-xl shadow-2xl flex flex-col"
      >
        {/* Modal Top Header */}
        <div className="sticky top-0 z-10 bg-[#121422] border-b border-[#21263d] px-5 py-3.5 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-orange-500/20 border border-orange-500/40 flex items-center justify-center text-orange-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="font-pixel text-sm sm:text-base text-slate-100 font-bold">
                  {isAr ? 'تقديم ستاف تاير تيستر (Staff TierTest Apply)' : 'Staff TierTester Application'}
                </h3>
                {/* Very small point secret bypass to open dashboard with pass mcpvp.com */}
                <button
                  type="button"
                  onClick={() => {
                    setShowSecretBypass(true);
                    setSecretPass('');
                    setSecretError(null);
                  }}
                  className="w-3 h-3 p-0.5 inline-flex items-center justify-center cursor-pointer group opacity-30 hover:opacity-100 transition-opacity"
                  title="•"
                  aria-label="Secret bypass point"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-500 group-hover:bg-amber-400 block transition-colors" />
                </button>
              </div>
              <div className="flex items-center gap-1 text-[11px] text-slate-400">
                <span>
                  {isAr ? 'انضم لفريق فاحصين التايرات الرسمي' : 'Apply to become an authorized Tier Evaluator'}
                </span>
                {/* Secondary subtle dot */}
                <button
                  type="button"
                  onClick={() => {
                    setShowSecretBypass(true);
                    setSecretPass('');
                    setSecretError(null);
                  }}
                  className="cursor-pointer text-slate-600 hover:text-amber-400 select-none text-[10px] px-0.5"
                  title="•"
                >
                  •
                </button>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Language Switch */}
            <button
              type="button"
              onClick={() => setLang(isAr ? 'en' : 'ar')}
              className="px-2.5 py-1 rounded bg-[#1c2035] hover:bg-[#282e4b] border border-[#2f3555] text-xs font-pixel text-orange-300 flex items-center gap-1.5 cursor-pointer transition-colors"
              title="Change Language / تغيير اللغة"
            >
              <Globe className="w-3 h-3 text-orange-400" />
              <span>{isAr ? 'English' : 'عربي'}</span>
            </button>

            {/* Close Button */}
            <button
              type="button"
              onClick={handleResetAndClose}
              className="p-1 rounded text-slate-400 hover:text-white hover:bg-white/10 cursor-pointer transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Form Body or Success Confirmation */}
        <div className="p-5 sm:p-6 space-y-5">
          {submitted ? (
            <div className="py-8 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-emerald-500/20 border-2 border-emerald-500 flex items-center justify-center mx-auto text-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.4)]">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div className="space-y-1">
                <h4 className="font-pixel text-lg text-emerald-300 font-bold">
                  {isAr ? 'تم إرسال تقديمك بنجاح!' : 'Application Sent Successfully!'}
                </h4>
                <p className="text-xs text-slate-300 max-w-md mx-auto">
                  {isAr 
                    ? 'وصل تقديمك الآن مباشرة إلى لوحة تحكم الاستاف (Dashboard). سيقوم الأونر بمراجعته وتحديد موعد اختبارك.'
                    : 'Your application has been received in the Staff Dashboard. The owner will review your claimed tier and credentials.'}
                </p>
              </div>

              <div className="bg-[#121526] border border-[#252a45] rounded-lg p-3 max-w-sm mx-auto text-xs space-y-1">
                <div className="flex justify-between text-slate-400">
                  <span>{isAr ? 'اسم اللاعب:' : 'IGN:'}</span>
                  <span className="font-bold text-slate-100">{username}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>{isAr ? 'التاير المعلن:' : 'Claimed Tier:'}</span>
                  <span className="font-bold text-orange-400">{claimedTier}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>{isAr ? 'ديسكورد:' : 'Discord:'}</span>
                  <span className="font-mono text-indigo-300">{discord}</span>
                </div>
              </div>

              <button
                type="button"
                onClick={handleResetAndClose}
                className="mc-button px-5 py-2 rounded text-xs font-pixel text-slate-900 bg-orange-500 hover:bg-orange-400 border-orange-300 font-bold cursor-pointer shadow"
              >
                {isAr ? 'إغلاق والعودة' : 'Close and Return'}
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4 text-xs">
              {errorMsg && (
                <div className="p-2.5 rounded bg-rose-500/15 border border-rose-500/40 text-rose-300 font-medium text-xs">
                  {errorMsg}
                </div>
              )}

              {/* Live Skin Avatar Preview & IGN */}
              <div className="flex items-center gap-3 p-3 rounded-lg bg-[#111322] border border-[#20253d]">
                <div className="w-12 h-12 rounded bg-[#090b14] border border-[#262c47] flex items-center justify-center shrink-0 overflow-hidden shadow-inner">
                  <PlayerAvatar username={username.trim() || 'Steve'} type="head" size={40} />
                </div>
                <div className="flex-1 min-w-0">
                  <label className="block text-slate-300 font-pixel mb-1">
                    {isAr ? 'اسمك داخل اللعبة (Minecraft IGN):' : 'Minecraft In-Game Name (IGN):'}
                  </label>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="e.g. Dream, JokingDK, XTki4ler"
                    className="w-full px-3 py-1.5 rounded bg-[#16192c] border border-[#2c3352] text-slate-100 text-xs font-mono focus:outline-none focus:border-orange-500"
                  />
                </div>
              </div>

              {/* Discord & Gmail Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Discord */}
                <div>
                  <label className="block text-slate-300 font-pixel mb-1 flex items-center gap-1.5">
                    <MessageSquare className="w-3.5 h-3.5 text-[#5865F2]" />
                    <span>{isAr ? 'حساب الديسكورد (Discord Tag):' : 'Discord Username / Tag:'}</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={discord}
                    onChange={(e) => setDiscord(e.target.value)}
                    placeholder="e.g. player#0001 or player_mc"
                    className="w-full px-3 py-1.5 rounded bg-[#16192c] border border-[#2c3352] text-slate-100 text-xs font-mono focus:outline-none focus:border-orange-500"
                  />
                </div>

                {/* Gmail */}
                <div>
                  <label className="block text-slate-300 font-pixel mb-1 flex items-center gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-orange-400" />
                    <span>{isAr ? 'الجيميل الرسمي (Gmail):' : 'Official Staff Gmail:'}</span>
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="e.g. player@gmail.com"
                    className="w-full px-3 py-1.5 rounded bg-[#16192c] border border-[#2c3352] text-slate-100 text-xs font-mono focus:outline-none focus:border-orange-500"
                  />
                </div>
              </div>

              {/* Question: What is your TierTest Rating? (tiertest كام؟) */}
              <div className="p-3 rounded-lg bg-[#111322] border border-[#20253d] space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <label className="text-orange-300 font-pixel text-xs font-bold flex items-center gap-1.5">
                    <Swords className="w-3.5 h-3.5 text-orange-400" />
                    <span>{isAr ? 'أنت TierTest كام في اللعبة؟ (Claimed Tier):' : 'What is your current TierTest level?'}</span>
                  </label>
                  <span className="font-pixel text-[11px] px-2 py-0.5 rounded bg-orange-500/20 text-orange-300 border border-orange-500/40 font-bold">
                    {claimedTier} · {overallTier}
                  </span>
                </div>

                {/* Tier Grade Selector (HT1..LT6) */}
                <div className="grid grid-cols-6 gap-1.5 text-center">
                  {TIER_GRADES.map((tier) => (
                    <button
                      type="button"
                      key={tier}
                      onClick={() => setClaimedTier(tier)}
                      className={`
                        py-1 rounded font-pixel text-[11px] cursor-pointer transition-all border
                        ${
                          claimedTier === tier
                            ? 'bg-orange-500 text-slate-950 border-orange-300 font-bold shadow-[0_0_8px_rgba(249,115,22,0.6)]'
                            : 'bg-[#16192c] text-slate-400 border-[#262c47] hover:border-slate-400'
                        }
                      `}
                    >
                      {tier}
                    </button>
                  ))}
                </div>

                {/* Overall Tier Category */}
                <div className="pt-1">
                  <label className="block text-[11px] text-slate-400 mb-1">
                    {isAr ? 'تصنيف المستوى العام (Overall Category):' : 'Overall Tier Classification:'}
                  </label>
                  <select
                    value={overallTier}
                    onChange={(e) => setOverallTier(e.target.value)}
                    className="w-full px-3 py-1.5 rounded bg-[#16192c] border border-[#2c3352] text-slate-100 text-xs font-pixel focus:outline-none focus:border-orange-500 cursor-pointer"
                  >
                    {OVERALL_TIERS.map((ot) => (
                      <option key={ot} value={ot}>
                        {ot}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Primary Kit & Weekly Availability */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Primary Kit */}
                <div>
                  <label className="block text-slate-300 font-pixel mb-1 flex items-center gap-1.5">
                    <Swords className="w-3.5 h-3.5 text-amber-400" />
                    <span>{isAr ? 'الكت المفضل للاختبار (Kit):' : 'Primary Testing Kit:'}</span>
                  </label>
                  <select
                    value={primaryKit}
                    onChange={(e) => setPrimaryKit(e.target.value as KitType)}
                    className="w-full px-3 py-1.5 rounded bg-[#16192c] border border-[#2c3352] text-slate-100 text-xs font-pixel focus:outline-none focus:border-orange-500 cursor-pointer"
                  >
                    {kits.map((k) => (
                      <option key={k.id} value={k.id}>
                        {k.name}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Hours available */}
                <div>
                  <label className="block text-slate-300 font-pixel mb-1 flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-slate-400" />
                    <span>{isAr ? 'التفرغ الأسبوعي:' : 'Weekly Availability:'}</span>
                  </label>
                  <select
                    value={weeklyHours}
                    onChange={(e) => setWeeklyHours(e.target.value)}
                    className="w-full px-3 py-1.5 rounded bg-[#16192c] border border-[#2c3352] text-slate-100 text-xs focus:outline-none focus:border-orange-500 cursor-pointer"
                  >
                    <option value="5-10 hours/week">5 - 10 hours/week (ساعات أسبوعياً)</option>
                    <option value="10-15 hours/week">10 - 15 hours/week (ساعات أسبوعياً)</option>
                    <option value="15-25 hours/week">15 - 25 hours/week (متفرغ جداً)</option>
                    <option value="25+ hours/week">25+ hours/week (يومي ومستمر)</option>
                  </select>
                </div>
              </div>

              {/* Experience / Why Apply */}
              <div>
                <label className="block text-slate-300 font-pixel mb-1">
                  {isAr ? 'خبرتك في الباتل وسبب رغبتك بالانضمام كـ Tier Tester:' : 'PvP experience and why you want to become a Tier Tester:'}
                </label>
                <textarea
                  required
                  rows={3}
                  value={experience}
                  onChange={(e) => setExperience(e.target.value)}
                  placeholder={
                    isAr
                      ? "اكتب خبرتك في السيرفرات والبطولات، أسلوب لعبك ومهاراتك في تقييم اللاعبين..."
                      : "Describe your duel tournaments history, mechanics evaluation skills, and why you should be accepted..."
                  }
                  className="w-full px-3 py-2 rounded bg-[#16192c] border border-[#2c3352] text-slate-100 text-xs focus:outline-none focus:border-orange-500 resize-none"
                />
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="mc-button w-full py-2.5 rounded font-pixel text-xs text-slate-950 bg-orange-500 hover:bg-orange-400 border-orange-300 font-bold flex items-center justify-center gap-2 cursor-pointer shadow-lg hover:scale-[1.01] transition-transform"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{isAr ? 'إرسال التقديم للداشبورد (Submit Application)' : 'Submit Application to Dashboard'}</span>
                </button>
              </div>
            </form>
          )}
        </div>
      </div>

      {/* Secret Bypass Password Modal (Pass: mcpvp.com) */}
      {showSecretBypass && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-100">
          <div className="w-full max-w-sm bg-[#0d0f1b] border-2 border-amber-500/80 rounded-xl p-5 shadow-2xl space-y-4 animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-[#20253d] pb-2.5">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-amber-400" />
                <span className="font-pixel text-xs text-amber-300 font-bold uppercase tracking-wider">
                  Secret Bypass Access
                </span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setShowSecretBypass(false);
                  setSecretPass('');
                  setSecretError(null);
                }}
                className="text-slate-400 hover:text-white p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Enter secret owner bypass key to unlock dashboard directly:
            </p>

            <form onSubmit={handleSecretBypassSubmit} className="space-y-3">
              <div>
                <input
                  type="password"
                  autoFocus
                  required
                  value={secretPass}
                  onChange={(e) => {
                    setSecretPass(e.target.value);
                    if (secretError) setSecretError(null);
                  }}
                  placeholder="Enter bypass password (mcpvp.com)..."
                  className="w-full px-3 py-2 bg-[#141729] border border-[#2c3254] rounded-lg text-slate-100 font-mono text-sm focus:outline-none focus:border-amber-400"
                />
              </div>

              {secretError && (
                <div className="text-xs text-rose-400 font-pixel bg-rose-500/10 border border-rose-500/30 p-2 rounded">
                  {secretError}
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setShowSecretBypass(false);
                    setSecretPass('');
                    setSecretError(null);
                  }}
                  className="px-3 py-1.5 text-xs text-slate-400 hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="mc-button px-4 py-2 rounded-lg text-xs font-pixel text-slate-950 bg-amber-400 hover:bg-amber-300 font-bold flex items-center gap-1.5 cursor-pointer shadow-md"
                >
                  <KeyRound className="w-3.5 h-3.5" />
                  <span>Unlock Dashboard</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

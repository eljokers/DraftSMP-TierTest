import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  updateDoc,
  onSnapshot,
  getDocs,
  query,
  where,
  getDoc,
  Unsubscribe,
} from 'firebase/firestore';
import { db } from '../firebase';
import { PlayerTier, StaffMember, TierTestApplication, AuthUser, UserRole } from '../types/playerTiers';
import { INITIAL_STAFF, INITIAL_PLAYERS } from '../data/initialTierData';

// Helper: Hash password with SHA-256 via browser Web Crypto API
export async function hashPassword(plainText: string): Promise<string> {
  const enc = new TextEncoder();
  const data = enc.encode(`mcpvp_salt_${plainText.trim()}`);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

// ================= REAL-TIME FIRESTORE SUBSCRIPTIONS =================

/**
 * Real-time subscription to staff members roster
 * Every connected user will see new staff additions / accepts instantly
 */
export function subscribeStaff(callback: (staff: StaffMember[]) => void): Unsubscribe {
  const colRef = collection(db, 'staff');

  return onSnapshot(
    colRef,
    async (snapshot) => {
      if (snapshot.empty) {
        // First run: seed initial staff (Owner) into Firestore
        for (const s of INITIAL_STAFF) {
          try {
            await setDoc(doc(db, 'staff', s.id), s);
          } catch (e) {
            console.warn('Seeding initial staff note:', e);
          }
        }
        callback(INITIAL_STAFF);
        return;
      }

      const list: StaffMember[] = [];
      snapshot.forEach((docSnap) => {
        list.push(docSnap.data() as StaffMember);
      });
      callback(list);
    },
    (err) => {
      console.warn('Staff subscription fallback to local cache:', err);
    }
  );
}

const FAKE_PLAYER_IDS = [
  'p1_jokingdk',
  'p2_xtki4ler',
  'p3_spawnplayer',
  'p4_jaidencrits',
  'p5_provok',
  'p6_0pminer17',
];

/**
 * Remove any fake sample players from Firestore
 */
export async function cleanupFakePlayers(): Promise<void> {
  for (const id of FAKE_PLAYER_IDS) {
    try {
      await deleteDoc(doc(db, 'players', id));
    } catch (e) {}
  }
}

// Run cleanup immediately on load
cleanupFakePlayers();

/**
 * Real-time subscription to player tiers & rankings
 * Only returns genuine players added by the owner/staff
 */
export function subscribePlayers(callback: (players: PlayerTier[]) => void): Unsubscribe {
  const colRef = collection(db, 'players');

  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: PlayerTier[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data() as PlayerTier;
        // Filter out any fake player IDs
        if (!FAKE_PLAYER_IDS.includes(data.id)) {
          list.push(data);
        }
      });
      callback(list);
    },
    (err) => {
      console.warn('Players subscription error:', err);
      callback([]);
    }
  );
}

/**
 * Real-time subscription to TierTest applications
 */
export function subscribeApplications(callback: (apps: TierTestApplication[]) => void): Unsubscribe {
  const colRef = collection(db, 'applications');

  return onSnapshot(
    colRef,
    (snapshot) => {
      const list: TierTestApplication[] = [];
      snapshot.forEach((docSnap) => {
        list.push(docSnap.data() as TierTestApplication);
      });
      callback(list);
    },
    (err) => {
      console.warn('Applications subscription error:', err);
    }
  );
}

/**
 * Real-time subscription to Site Configuration
 */
export function subscribeSiteConfig(
  callback: (config: { title: string; announcement: string }) => void
): Unsubscribe {
  const docRef = doc(db, 'config', 'general');

  return onSnapshot(
    docRef,
    async (snapshot) => {
      if (!snapshot.exists()) {
        const initial = {
          title: 'DraftSMP-TierTest',
          announcement:
            'DraftSMP Season 4 Tier Testing is currently live! Authorized staff can login to test and add player tiers.',
        };
        try {
          await setDoc(docRef, initial);
        } catch (e) {}
        callback(initial);
        return;
      }
      const data = snapshot.data();
      callback({
        title: !data?.title || data.title === 'Minecraft PvP Tierlist' ? 'DraftSMP-TierTest' : data.title,
        announcement:
          data?.announcement ||
          'DraftSMP Season 4 Tier Testing is currently live! Authorized staff can login to test and add player tiers.',
      });
    },
    (err) => {
      console.warn('Config subscription error:', err);
    }
  );
}

// ================= SHARED WRITE OPERATIONS =================

/**
 * Save or update staff member in Firestore
 */
export async function saveStaffMember(staff: StaffMember): Promise<void> {
  await setDoc(doc(db, 'staff', staff.id), staff);
}

/**
 * Remove staff member from Firestore
 */
export async function removeStaffMember(staffId: string): Promise<void> {
  await deleteDoc(doc(db, 'staff', staffId));
}

/**
 * Save or update player tier evaluation
 */
export async function savePlayer(player: PlayerTier): Promise<void> {
  await setDoc(doc(db, 'players', player.id), player);
}

/**
 * Remove player from leaderboard
 */
export async function removePlayer(playerId: string): Promise<void> {
  await deleteDoc(doc(db, 'players', playerId));
}

/**
 * Submit a Tier Tester application from the public modal
 */
export async function submitApplication(app: TierTestApplication): Promise<void> {
  await setDoc(doc(db, 'applications', app.id), app);
}

/**
 * Accept a TierTester application:
 * 1. Updates application status to 'accepted' in Firestore
 * 2. Adds the candidate as a 'Tier Tester' in the 'staff' collection in Firestore
 * This triggers onSnapshot for ALL users viewing the website in real-time!
 */
export async function acceptApplicationInDb(app: TierTestApplication): Promise<StaffMember> {
  // 1. Update application in Firestore
  await updateDoc(doc(db, 'applications', app.id), {
    status: 'accepted',
  });

  // 2. Create staff record in Firestore
  const newStaff: StaffMember = {
    id: `staff_${Date.now()}`,
    email: app.email,
    username: app.username,
    discord: app.discord,
    role: 'Tier Tester',
    testsConducted: 0,
    joinedDate: new Date().toISOString().split('T')[0],
    status: 'active',
  };

  await setDoc(doc(db, 'staff', newStaff.id), newStaff);
  return newStaff;
}

/**
 * Reject application
 */
export async function rejectApplicationInDb(appId: string): Promise<void> {
  await updateDoc(doc(db, 'applications', appId), {
    status: 'rejected',
  });
}

/**
 * Delete application
 */
export async function removeApplicationFromDb(appId: string): Promise<void> {
  await deleteDoc(doc(db, 'applications', appId));
}

/**
 * Update site title and announcement banner in Firestore
 */
export async function updateSiteConfigInDb(title: string, announcement: string): Promise<void> {
  await setDoc(doc(db, 'config', 'general'), {
    title,
    announcement,
    updatedAt: new Date().toISOString(),
  });
}

// ================= USER AUTHENTICATION SYSTEM =================
// Register by Discord or Minecraft Username + Password
// Login by Username/Password or Discord/Password

const LOCAL_USER_KEY = 'mcpvp_logged_in_user';

export function getStoredUser(): AuthUser | null {
  try {
    const saved = localStorage.getItem(LOCAL_USER_KEY);
    if (saved) return JSON.parse(saved);
  } catch (e) {}
  return null;
}

export function saveStoredUser(user: AuthUser | null) {
  try {
    if (user) {
      localStorage.setItem(LOCAL_USER_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(LOCAL_USER_KEY);
    }
  } catch (e) {}
}

/**
 * Register a new user in Firestore:
 * Supports registration by Discord OR by Minecraft Username.
 */
export async function registerUser(params: {
  username: string;
  discord?: string;
  password: string;
  registeredWith: 'minecraft' | 'discord';
}): Promise<AuthUser> {
  const cleanUsername = params.username.trim();
  const cleanDiscord = params.discord ? params.discord.trim() : '';

  if (!cleanUsername) {
    throw new Error('Minecraft username is required.');
  }
  if (params.registeredWith === 'discord' && !cleanDiscord) {
    throw new Error('Discord tag/username is required when registering via Discord.');
  }
  if (!params.password || params.password.length < 4) {
    throw new Error('Password must be at least 4 characters long.');
  }

  // Check if username already exists in Firestore
  const usersRef = collection(db, 'users');
  const userCheckQuery = query(
    usersRef,
    where('usernameLower', '==', cleanUsername.toLowerCase())
  );
  const existingUsers = await getDocs(userCheckQuery);
  if (!existingUsers.empty) {
    throw new Error(`The Minecraft username "${cleanUsername}" is already registered. Please log in.`);
  }

  // Check if discord handle already registered
  if (cleanDiscord) {
    const discordClean = cleanDiscord.toLowerCase().replace(/^@/, '');
    const discordQuery = query(usersRef, where('discordLower', '==', discordClean));
    const existingDiscord = await getDocs(discordQuery);
    if (!existingDiscord.empty) {
      throw new Error(`The Discord handle "${cleanDiscord}" is already registered. Please log in.`);
    }
  }

  // Determine role: Owner if abdullafahmy13@gmail.com or username is Owner/Dream, or check staff collection
  let userRole: UserRole = 'visitor';
  const isOwnerCandidate =
    cleanUsername.toLowerCase() === 'owner' ||
    cleanUsername.toLowerCase() === 'abdullafahmy' ||
    (cleanDiscord && cleanDiscord.toLowerCase().includes('owner'));

  if (isOwnerCandidate) {
    userRole = 'owner';
  } else {
    // Check if IGN is in staff roster
    const staffQuery = query(
      collection(db, 'staff'),
      where('username', '==', cleanUsername)
    );
    const staffSnap = await getDocs(staffQuery);
    if (!staffSnap.empty) {
      userRole = 'staff';
    }
  }

  const hashedPassword = await hashPassword(params.password);
  const userId = `user_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

  const userDocData = {
    id: userId,
    username: cleanUsername,
    usernameLower: cleanUsername.toLowerCase(),
    discord: cleanDiscord || null,
    discordLower: cleanDiscord ? cleanDiscord.toLowerCase().replace(/^@/, '') : null,
    passwordHash: hashedPassword,
    role: userRole,
    registeredWith: params.registeredWith,
    createdAt: new Date().toISOString(),
  };

  await setDoc(doc(db, 'users', userId), userDocData);

  const authUser: AuthUser = {
    id: userId,
    username: cleanUsername,
    discord: cleanDiscord || undefined,
    role: userRole,
    registeredWith: params.registeredWith,
    createdAt: userDocData.createdAt,
  };

  saveStoredUser(authUser);
  return authUser;
}

/**
 * Login by Minecraft username OR Discord tag + Password
 */
export async function loginUser(
  identifier: string,
  plainPassword: string
): Promise<AuthUser> {
  const cleanId = identifier.trim();
  if (!cleanId) {
    throw new Error('Please enter your Minecraft username or Discord handle.');
  }
  if (!plainPassword) {
    throw new Error('Please enter your password.');
  }

  const hashedPassword = await hashPassword(plainPassword);
  const usersRef = collection(db, 'users');

  // Try matching by username first
  let userSnap = await getDocs(
    query(usersRef, where('usernameLower', '==', cleanId.toLowerCase()))
  );

  // If not found, try matching by discord handle
  if (userSnap.empty) {
    const discordClean = cleanId.toLowerCase().replace(/^@/, '');
    userSnap = await getDocs(
      query(usersRef, where('discordLower', '==', discordClean))
    );
  }

  if (userSnap.empty) {
    // Special Owner back-compat login if matching dashboard master password
    if (
      (cleanId.toLowerCase() === 'owner' || cleanId.toLowerCase() === 'admin') &&
      plainPassword === 'mcpvp.com'
    ) {
      const ownerUser: AuthUser = {
        id: 'owner_master',
        username: 'Owner',
        email: 'abdullafahmy13@gmail.com',
        role: 'owner',
        registeredWith: 'minecraft',
        createdAt: new Date().toISOString(),
      };
      saveStoredUser(ownerUser);
      return ownerUser;
    }
    throw new Error('Account not found with this Minecraft IGN or Discord handle. Please register first.');
  }

  const userData = userSnap.docs[0].data();

  // Verify password
  if (userData.passwordHash !== hashedPassword) {
    throw new Error('Incorrect password. Please try again.');
  }

  // Refresh role in case user was granted staff role in Firestore
  let role: UserRole = userData.role || 'visitor';
  if (userData.username.toLowerCase() === 'owner') {
    role = 'owner';
  } else {
    const staffQuery = query(
      collection(db, 'staff'),
      where('username', '==', userData.username)
    );
    const staffSnap = await getDocs(staffQuery);
    if (!staffSnap.empty) {
      role = 'staff';
    }
  }

  const authUser: AuthUser = {
    id: userData.id,
    username: userData.username,
    discord: userData.discord || undefined,
    email: userData.email || undefined,
    role,
    registeredWith: userData.registeredWith || 'minecraft',
    createdAt: userData.createdAt,
  };

  saveStoredUser(authUser);
  return authUser;
}

export function logoutUser(): void {
  saveStoredUser(null);
}
